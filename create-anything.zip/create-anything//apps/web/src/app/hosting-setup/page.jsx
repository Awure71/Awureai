"use client";

import { useState, useEffect } from "react";
import {
  Server,
  Globe,
  Database,
  Shield,
  CheckCircle,
  AlertCircle,
  ExternalLink,
  Code,
  Zap,
  Users,
  BarChart3,
} from "lucide-react";

export default function HostingSetupPage() {
  const [activeStep, setActiveStep] = useState(1);
  const [completedSteps, setCompletedSteps] = useState(new Set());
  const [deployments, setDeployments] = useState([]);

  useEffect(() => {
    fetchDeployments();
  }, []);

  const fetchDeployments = async () => {
    try {
      const response = await fetch("/api/hosting");
      const data = await response.json();
      setDeployments(data.deployments || []);
    } catch (error) {
      console.error("Failed to fetch deployments:", error);
    }
  };

  const steps = [
    {
      id: 1,
      title: "Domain Purchase",
      description: "Secure awureai.com domain",
      icon: Globe,
      details: [
        "Purchase awureai.com domain from registrar",
        "Point DNS to AwureAI hosting servers",
        "Configure wildcard subdomain support",
        "Set up SSL certificate automation",
      ],
    },
    {
      id: 2,
      title: "Infrastructure Setup",
      description: "Cloud hosting infrastructure",
      icon: Server,
      details: [
        "Deploy hosting servers (AWS/GCP/Digital Ocean)",
        "Configure load balancers and CDN",
        "Set up file storage (S3-compatible)",
        "Implement auto-scaling groups",
      ],
    },
    {
      id: 3,
      title: "Database & Storage",
      description: "Persistent data infrastructure",
      icon: Database,
      details: [
        "Scale database for hosting metadata",
        "Implement file storage service",
        "Set up backup and disaster recovery",
        "Configure monitoring and logging",
      ],
    },
    {
      id: 4,
      title: "SSL & Security",
      description: "Security and certificates",
      icon: Shield,
      details: [
        "Implement Let's Encrypt automation",
        "Configure WAF and DDoS protection",
        "Set up security monitoring",
        "Implement rate limiting",
      ],
    },
  ];

  const features = [
    {
      icon: Zap,
      title: "Instant Deployments",
      description:
        "Deploy projects in seconds with our optimized infrastructure",
    },
    {
      icon: Globe,
      title: "Global CDN",
      description: "Serve content worldwide with edge caching",
    },
    {
      icon: Shield,
      title: "SSL Included",
      description: "Automatic HTTPS certificates for all deployments",
    },
    {
      icon: BarChart3,
      title: "Analytics",
      description: "Track deployment usage and performance metrics",
    },
    {
      icon: Users,
      title: "User Management",
      description: "Multi-tenant hosting with user isolation",
    },
    {
      icon: Code,
      title: "Custom Domains",
      description: "Support for custom domain mapping (future)",
    },
  ];

  const toggleStepCompletion = (stepId) => {
    const newCompleted = new Set(completedSteps);
    if (newCompleted.has(stepId)) {
      newCompleted.delete(stepId);
    } else {
      newCompleted.add(stepId);
    }
    setCompletedSteps(newCompleted);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-6">
            <div className="p-4 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full">
              <Server className="text-white" size={48} />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            AwureAI Hosting Infrastructure
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Build your own hosting platform to compete with Vercel and Netlify.
            Give your users instant deployments on awureai.com subdomains.
          </p>
        </div>

        {/* Current Status */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Current Status
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="p-3 bg-green-100 rounded-full w-16 h-16 mx-auto mb-2 flex items-center justify-center">
                <CheckCircle className="text-green-600" size={24} />
              </div>
              <h3 className="font-semibold text-gray-900">Database Ready</h3>
              <p className="text-sm text-gray-600">
                Hosting tables created and functional
              </p>
            </div>
            <div className="text-center">
              <div className="p-3 bg-green-100 rounded-full w-16 h-16 mx-auto mb-2 flex items-center justify-center">
                <CheckCircle className="text-green-600" size={24} />
              </div>
              <h3 className="font-semibold text-gray-900">API Complete</h3>
              <p className="text-sm text-gray-600">
                Hosting API endpoints implemented
              </p>
            </div>
            <div className="text-center">
              <div className="p-3 bg-yellow-100 rounded-full w-16 h-16 mx-auto mb-2 flex items-center justify-center">
                <AlertCircle className="text-yellow-600" size={24} />
              </div>
              <h3 className="font-semibold text-gray-900">Domain Needed</h3>
              <p className="text-sm text-gray-600">
                Purchase awureai.com domain
              </p>
            </div>
            <div className="text-center">
              <div className="p-3 bg-red-100 rounded-full w-16 h-16 mx-auto mb-2 flex items-center justify-center">
                <AlertCircle className="text-red-600" size={24} />
              </div>
              <h3 className="font-semibold text-gray-900">Infrastructure</h3>
              <p className="text-sm text-gray-600">
                Cloud hosting setup required
              </p>
            </div>
          </div>
        </div>

        {/* Implementation Steps */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Implementation Roadmap
          </h2>
          <div className="space-y-6">
            {steps.map((step) => {
              const Icon = step.icon;
              const isCompleted = completedSteps.has(step.id);
              const isActive = activeStep === step.id;

              return (
                <div
                  key={step.id}
                  className={`border rounded-lg p-6 transition-all cursor-pointer ${
                    isCompleted
                      ? "border-green-500 bg-green-50"
                      : isActive
                        ? "border-blue-500 bg-blue-50"
                        : "border-gray-200 hover:border-gray-300"
                  }`}
                  onClick={() => setActiveStep(step.id)}
                >
                  <div className="flex items-start space-x-4">
                    <div
                      className={`p-3 rounded-full ${
                        isCompleted
                          ? "bg-green-500"
                          : isActive
                            ? "bg-blue-500"
                            : "bg-gray-300"
                      }`}
                    >
                      <Icon className="text-white" size={24} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-lg font-semibold text-gray-900">
                          Step {step.id}: {step.title}
                        </h3>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleStepCompletion(step.id);
                          }}
                          className={`px-3 py-1 rounded-full text-sm font-medium ${
                            isCompleted
                              ? "bg-green-500 text-white"
                              : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                          }`}
                        >
                          {isCompleted ? "✓ Done" : "Mark Complete"}
                        </button>
                      </div>
                      <p className="text-gray-600 mb-4">{step.description}</p>
                      {isActive && (
                        <ul className="space-y-2">
                          {step.details.map((detail, index) => (
                            <li
                              key={index}
                              className="flex items-center space-x-2 text-sm text-gray-700"
                            >
                              <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>
                              <span>{detail}</span>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Features Overview */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Platform Features
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div
                  key={index}
                  className="flex items-start space-x-4 p-4 border border-gray-200 rounded-lg"
                >
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <Icon className="text-blue-600" size={20} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-1">
                      {feature.title}
                    </h3>
                    <p className="text-sm text-gray-600">
                      {feature.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Current Deployments */}
        {deployments.length > 0 && (
          <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              Test Deployments
            </h2>
            <div className="space-y-4">
              {deployments.slice(0, 5).map((deployment) => (
                <div
                  key={deployment.id}
                  className="flex items-center justify-between p-4 border border-gray-200 rounded-lg"
                >
                  <div>
                    <h3 className="font-semibold text-gray-900">
                      {deployment.project_name}
                    </h3>
                    <p className="text-sm text-gray-600">
                      {deployment.subdomain}.awureai.com
                    </p>
                    <p className="text-xs text-gray-500">
                      Created:{" "}
                      {new Date(deployment.created_at).toLocaleString()}
                    </p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span
                      className={`px-2 py-1 rounded-full text-xs font-medium ${
                        deployment.status === "success"
                          ? "bg-green-100 text-green-800"
                          : deployment.status === "building"
                            ? "bg-yellow-100 text-yellow-800"
                            : "bg-red-100 text-red-800"
                      }`}
                    >
                      {deployment.status}
                    </span>
                    {deployment.status === "success" && (
                      <a
                        href={deployment.full_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:text-blue-800"
                      >
                        <ExternalLink size={16} />
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Cost Analysis */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Estimated Costs
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Domain & Setup
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>awureai.com domain (annual)</span>
                  <span>$15-50/year</span>
                </div>
                <div className="flex justify-between">
                  <span>SSL certificates</span>
                  <span>Free (Let's Encrypt)</span>
                </div>
                <div className="flex justify-between">
                  <span>Development time</span>
                  <span>40-80 hours</span>
                </div>
              </div>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Monthly Operating Costs
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Cloud servers (start)</span>
                  <span>$50-200/month</span>
                </div>
                <div className="flex justify-between">
                  <span>CDN & storage</span>
                  <span>$10-50/month</span>
                </div>
                <div className="flex justify-between">
                  <span>Monitoring & logs</span>
                  <span>$20-100/month</span>
                </div>
                <div className="border-t pt-2 font-semibold">
                  <div className="flex justify-between">
                    <span>Total (start)</span>
                    <span>$80-350/month</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Next Steps */}
        <div className="mt-8 text-center">
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl p-8 text-white">
            <h2 className="text-2xl font-bold mb-4">Ready to Get Started?</h2>
            <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
              The backend infrastructure is already built. You just need to buy
              the domain and set up the cloud hosting to give your users their
              own deployment platform.
            </p>
            <div className="space-x-4">
              <a
                href="https://namecheap.com"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center px-6 py-3 bg-white text-blue-600 rounded-lg font-medium hover:bg-blue-50 transition-colors"
              >
                <Globe className="mr-2" size={20} />
                Buy Domain
              </a>
              <a
                href="/test-deploy"
                className="inline-flex items-center px-6 py-3 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-400 transition-colors"
              >
                <Code className="mr-2" size={20} />
                Test System
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
