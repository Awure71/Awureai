import { useState } from "react";
import { Rocket, CheckCircle, Globe, ExternalLink } from "lucide-react";

export default function TestDeploymentPage() {
  const [deploymentStatus, setDeploymentStatus] = useState(null);
  const [isDeploying, setIsDeploying] = useState(false);
  const [logs, setLogs] = useState([]);

  const testDeployment = async () => {
    setIsDeploying(true);
    setLogs(["🚀 Starting test deployment..."]);

    try {
      // Test deployment with the demo provider
      const response = await fetch("/api/deploy", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          projectId: "test-deployment",
          provider: "awureai-hosting",
          files: [
            {
              name: "index.html",
              content: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AwureAI Test Deployment</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            text-align: center;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            background: rgba(255, 255, 255, 0.1);
            padding: 40px;
            border-radius: 20px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        h1 {
            font-size: 3rem;
            margin-bottom: 20px;
            background: linear-gradient(45deg, #fff, #e0e7ff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        p {
            font-size: 1.2rem;
            opacity: 0.9;
            margin-bottom: 30px;
        }
        .success-badge {
            background: rgba(34, 197, 94, 0.2);
            color: #22c55e;
            padding: 12px 24px;
            border-radius: 50px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-weight: 500;
            border: 1px solid rgba(34, 197, 94, 0.3);
        }
        .timestamp {
            margin-top: 20px;
            font-size: 0.9rem;
            opacity: 0.7;
        }
        .features {
            margin-top: 30px;
            text-align: left;
        }
        .features h3 {
            margin-bottom: 15px;
            color: #e0e7ff;
        }
        .features ul {
            list-style: none;
            space-y: 8px;
        }
        .features li {
            padding: 5px 0;
            opacity: 0.8;
        }
        .features li:before {
            content: '✅ ';
            margin-right: 8px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 AwureAI</h1>
        <p>Your deployment system is working perfectly!</p>
        <div class="success-badge">
            ✅ Deployment Successful
        </div>
        <div class="timestamp">
            Deployed on ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}
        </div>
        
        <div class="features">
            <h3>Deployment Features:</h3>
            <ul>
                <li>Vercel Integration</li>
                <li>Netlify Support</li>
                <li>Instant Deployments</li>
                <li>HTTPS by Default</li>
                <li>Global CDN</li>
                <li>Custom Domains</li>
            </ul>
        </div>
    </div>
</body>
</html>`,
            },
            {
              name: "robots.txt",
              content: `User-agent: *
Allow: /

Sitemap: /sitemap.xml`,
            },
          ],
          projectName: "AwureAI Test Deployment",
        }),
      });

      const data = await response.json();

      if (data.deployment) {
        setDeploymentStatus(data.deployment);

        // Poll for status updates
        const pollInterval = setInterval(async () => {
          try {
            const statusResponse = await fetch(
              "/api/deploy?projectId=test-deployment",
            );
            const statusData = await statusResponse.json();

            if (statusData.deployment) {
              setDeploymentStatus(statusData.deployment);
              setLogs(statusData.deployment.buildLogs || []);

              if (
                statusData.deployment.status === "success" ||
                statusData.deployment.status === "failed"
              ) {
                setIsDeploying(false);
                clearInterval(pollInterval);
              }
            }
          } catch (error) {
            console.error("Status poll failed:", error);
            clearInterval(pollInterval);
            setIsDeploying(false);
          }
        }, 1000);
      }
    } catch (error) {
      setLogs((prev) => [...prev, `❌ Error: ${error.message}`]);
      setIsDeploying(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-6">
            <div className="p-4 bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl">
              <Rocket className="text-white" size={32} />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Test Your Deployment System
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Verify that your AwureAI deployment system is working correctly by
            deploying a test site.
          </p>
        </div>

        {/* Test Deployment Section */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 mb-8">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-semibold text-gray-900 mb-2">
              Deploy Test Site
            </h2>
            <p className="text-gray-600">
              This will deploy a simple test page using the demo hosting
              provider.
            </p>
          </div>

          {!deploymentStatus && !isDeploying && (
            <div className="text-center">
              <button
                onClick={testDeployment}
                className="inline-flex items-center space-x-3 bg-blue-600 hover:bg-blue-700 text-white font-medium px-8 py-4 rounded-lg text-lg transition-colors"
              >
                <Rocket size={20} />
                <span>Deploy Test Site</span>
              </button>
            </div>
          )}

          {/* Deployment Status */}
          {(deploymentStatus || isDeploying) && (
            <div className="space-y-6">
              {/* Status Indicator */}
              <div className="flex items-center justify-center space-x-3">
                {deploymentStatus?.status === "success" && (
                  <>
                    <CheckCircle className="text-green-600" size={24} />
                    <span className="text-green-600 font-semibold">
                      Deployment Successful!
                    </span>
                  </>
                )}
                {deploymentStatus?.status === "building" && (
                  <>
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
                    <span className="text-blue-600 font-semibold">
                      Deploying...
                    </span>
                  </>
                )}
                {deploymentStatus?.status === "failed" && (
                  <>
                    <div className="text-red-600" size={24}>
                      ❌
                    </div>
                    <span className="text-red-600 font-semibold">
                      Deployment Failed
                    </span>
                  </>
                )}
              </div>

              {/* Live URL */}
              {deploymentStatus?.url && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <Globe className="text-green-600" size={20} />
                      <div>
                        <p className="font-medium text-green-900">Live Site</p>
                        <p className="text-sm text-green-700">
                          {deploymentStatus.url}
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() =>
                        window.open(deploymentStatus.url, "_blank")
                      }
                      className="flex items-center space-x-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md text-sm transition-colors"
                    >
                      <ExternalLink size={16} />
                      <span>Visit Site</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Build Logs */}
              <div className="bg-gray-900 rounded-lg p-4">
                <h3 className="text-gray-300 font-medium mb-3">
                  Deployment Logs
                </h3>
                <div className="font-mono text-sm space-y-1 max-h-48 overflow-y-auto">
                  {logs.map((log, index) => (
                    <div key={index} className="text-green-400">
                      {log}
                    </div>
                  ))}
                  {isDeploying && (
                    <div className="text-blue-400 flex items-center space-x-2">
                      <div className="animate-pulse">●</div>
                      <span>Building...</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Try Again Button */}
              {deploymentStatus?.status === "success" && (
                <div className="text-center">
                  <button
                    onClick={() => {
                      setDeploymentStatus(null);
                      setLogs([]);
                    }}
                    className="inline-flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-medium"
                  >
                    <Rocket size={16} />
                    <span>Deploy Another Test</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Next Steps */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
          <h3 className="text-blue-900 font-semibold mb-3">Next Steps</h3>
          <div className="space-y-2 text-sm text-blue-800">
            <p>✅ Test deployment working</p>
            <p>🔧 Set up Vercel or Netlify tokens for real deployments</p>
            <p>🚀 Deploy your actual projects to the web</p>
            <p>🌐 Share your creations with the world</p>
          </div>
        </div>
      </div>
    </div>
  );
}
