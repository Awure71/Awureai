"use client";

import { useState } from "react";
import {
  Server,
  Globe,
  Shield,
  CheckCircle,
  Copy,
  ExternalLink,
  ArrowRight,
  Terminal,
  Database,
  Cloud,
} from "lucide-react";

export default function NextStepsPage() {
  const [copiedStep, setCopiedStep] = useState(null);

  const copyToClipboard = (text, stepId) => {
    navigator.clipboard.writeText(text);
    setCopiedStep(stepId);
    setTimeout(() => setCopiedStep(null), 2000);
  };

  const steps = [
    {
      id: 1,
      title: "Choose Your Cloud Provider",
      description: "Pick where to host your infrastructure",
      icon: Cloud,
      options: [
        {
          name: "DigitalOcean",
          price: "$6-12/month to start",
          ease: "Easiest",
          recommended: true,
          setup: "1-click droplet + Docker",
        },
        {
          name: "AWS",
          price: "$20-50/month to start",
          ease: "Complex",
          setup: "EC2 + ALB + Route53",
        },
        {
          name: "Vercel/Netlify",
          price: "$20-100/month",
          ease: "Medium",
          setup: "Serverless functions",
        },
      ],
    },
    {
      id: 2,
      title: "Set Up DNS in GoDaddy",
      description: "Point your domain to your servers",
      icon: Globe,
      instructions: [
        "Go to GoDaddy DNS Management",
        "Delete existing A records",
        "Add these records:",
      ],
      dnsRecords: [
        { type: "A", name: "@", value: "YOUR_SERVER_IP", ttl: "600" },
        { type: "A", name: "*", value: "YOUR_SERVER_IP", ttl: "600" },
        { type: "CNAME", name: "www", value: "awureai.com", ttl: "600" },
      ],
    },
    {
      id: 3,
      title: "Deploy Your Hosting Server",
      description: "Run the actual hosting infrastructure",
      icon: Server,
      dockerCommand: `# Copy your entire app to server, then run:
docker run -d \\
  --name awureai-hosting \\
  -p 80:3000 \\
  -p 443:3000 \\
  -e DATABASE_URL="your_db_url" \\
  -e DOMAIN="awureai.com" \\
  --restart unless-stopped \\
  your-app-image`,
    },
    {
      id: 4,
      title: "Set Up SSL & Reverse Proxy",
      description: "Enable HTTPS for all subdomains",
      icon: Shield,
      nginxConfig: `# /etc/nginx/sites-available/awureai.com
server {
    listen 80;
    server_name *.awureai.com awureai.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl;
    server_name *.awureai.com awureai.com;
    
    ssl_certificate /etc/letsencrypt/live/awureai.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/awureai.com/privkey.pem;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}`,
      certbotCommand: "certbot --nginx -d awureai.com -d *.awureai.com",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-6">
            <div className="p-4 bg-gradient-to-r from-green-600 to-blue-600 rounded-full">
              <CheckCircle className="text-white" size={48} />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            🎉 Domain Purchased!
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Great job buying <strong>awureai.com</strong>! Now let's get your
            hosting platform live in about 30 minutes.
          </p>
        </div>

        {/* Quick Overview */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            What You're Building
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <Globe className="mx-auto mb-2 text-blue-600" size={32} />
              <h3 className="font-semibold">awureai.com</h3>
              <p className="text-sm text-gray-600">Main hosting platform</p>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <ArrowRight className="mx-auto mb-2 text-green-600" size={32} />
              <h3 className="font-semibold">*.awureai.com</h3>
              <p className="text-sm text-gray-600">User project subdomains</p>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <Server className="mx-auto mb-2 text-purple-600" size={32} />
              <h3 className="font-semibold">Your Platform</h3>
              <p className="text-sm text-gray-600">Like Vercel/Netlify</p>
            </div>
          </div>
        </div>

        {/* Implementation Steps */}
        {steps.map((step) => {
          const Icon = step.icon;
          return (
            <div
              key={step.id}
              className="bg-white rounded-xl shadow-lg p-6 mb-6"
            >
              <div className="flex items-center mb-4">
                <div className="p-3 bg-blue-100 rounded-full mr-4">
                  <Icon className="text-blue-600" size={24} />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-gray-900">
                    Step {step.id}: {step.title}
                  </h2>
                  <p className="text-gray-600">{step.description}</p>
                </div>
              </div>

              {/* Cloud Provider Options */}
              {step.options && (
                <div className="space-y-3">
                  {step.options.map((option, index) => (
                    <div
                      key={index}
                      className={`border rounded-lg p-4 ${
                        option.recommended
                          ? "border-green-500 bg-green-50"
                          : "border-gray-200"
                      }`}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-semibold text-gray-900 flex items-center">
                            {option.name}
                            {option.recommended && (
                              <span className="ml-2 px-2 py-1 bg-green-500 text-white text-xs rounded-full">
                                Recommended
                              </span>
                            )}
                          </h3>
                          <p className="text-sm text-gray-600 mt-1">
                            {option.setup}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-gray-900">
                            {option.price}
                          </p>
                          <p className="text-sm text-gray-600">{option.ease}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* DNS Instructions */}
              {step.dnsRecords && (
                <div className="space-y-4">
                  <ol className="list-decimal list-inside space-y-2 text-gray-700">
                    {step.instructions.map((instruction, index) => (
                      <li key={index}>{instruction}</li>
                    ))}
                  </ol>

                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="overflow-x-auto">
                      <table className="min-w-full">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left py-2 px-3 font-medium">
                              Type
                            </th>
                            <th className="text-left py-2 px-3 font-medium">
                              Name
                            </th>
                            <th className="text-left py-2 px-3 font-medium">
                              Value
                            </th>
                            <th className="text-left py-2 px-3 font-medium">
                              TTL
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {step.dnsRecords.map((record, index) => (
                            <tr key={index}>
                              <td className="py-2 px-3 font-mono text-sm">
                                {record.type}
                              </td>
                              <td className="py-2 px-3 font-mono text-sm">
                                {record.name}
                              </td>
                              <td className="py-2 px-3 font-mono text-sm text-blue-600">
                                {record.value}
                              </td>
                              <td className="py-2 px-3 font-mono text-sm">
                                {record.ttl}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    <p className="text-sm text-gray-600 mt-2">
                      💡 Replace <code>YOUR_SERVER_IP</code> with your actual
                      server IP
                    </p>
                  </div>
                </div>
              )}

              {/* Docker Command */}
              {step.dockerCommand && (
                <div className="space-y-3">
                  <div className="bg-gray-900 rounded-lg p-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-green-400 font-mono text-sm">
                        Terminal
                      </span>
                      <button
                        onClick={() =>
                          copyToClipboard(
                            step.dockerCommand,
                            `docker-${step.id}`,
                          )
                        }
                        className="text-gray-400 hover:text-white"
                      >
                        {copiedStep === `docker-${step.id}` ? (
                          <CheckCircle size={16} />
                        ) : (
                          <Copy size={16} />
                        )}
                      </button>
                    </div>
                    <pre className="text-green-400 font-mono text-sm whitespace-pre-wrap">
                      {step.dockerCommand}
                    </pre>
                  </div>
                </div>
              )}

              {/* Nginx Config */}
              {step.nginxConfig && (
                <div className="space-y-3">
                  <div className="bg-gray-900 rounded-lg p-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-green-400 font-mono text-sm">
                        nginx.conf
                      </span>
                      <button
                        onClick={() =>
                          copyToClipboard(step.nginxConfig, `nginx-${step.id}`)
                        }
                        className="text-gray-400 hover:text-white"
                      >
                        {copiedStep === `nginx-${step.id}` ? (
                          <CheckCircle size={16} />
                        ) : (
                          <Copy size={16} />
                        )}
                      </button>
                    </div>
                    <pre className="text-green-400 font-mono text-sm whitespace-pre-wrap">
                      {step.nginxConfig}
                    </pre>
                  </div>

                  <div className="bg-gray-900 rounded-lg p-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-green-400 font-mono text-sm">
                        SSL Certificate
                      </span>
                      <button
                        onClick={() =>
                          copyToClipboard(
                            step.certbotCommand,
                            `cert-${step.id}`,
                          )
                        }
                        className="text-gray-400 hover:text-white"
                      >
                        {copiedStep === `cert-${step.id}` ? (
                          <CheckCircle size={16} />
                        ) : (
                          <Copy size={16} />
                        )}
                      </button>
                    </div>
                    <pre className="text-green-400 font-mono text-sm">
                      {step.certbotCommand}
                    </pre>
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {/* Quick Links */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl p-8 text-white text-center">
          <h2 className="text-2xl font-bold mb-4">🚀 Ready to Launch!</h2>
          <p className="text-blue-100 mb-6">
            Your hosting platform backend is ready. Once you complete the steps
            above, users can deploy to <strong>*.awureai.com</strong> instantly!
          </p>
          <div className="space-x-4">
            <a
              href="https://www.digitalocean.com/products/droplets"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-6 py-3 bg-white text-blue-600 rounded-lg font-medium hover:bg-blue-50 transition-colors"
            >
              <Cloud className="mr-2" size={20} />
              Get DigitalOcean Server
            </a>
            <a
              href="/test-deploy"
              className="inline-flex items-center px-6 py-3 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-400 transition-colors"
            >
              <Terminal className="mr-2" size={20} />
              Test Current System
            </a>
          </div>
        </div>

        {/* Timeline */}
        <div className="mt-8 bg-white rounded-xl shadow-lg p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">
            ⏰ Expected Timeline
          </h2>
          <div className="space-y-3">
            <div className="flex items-center">
              <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
              <span>
                <strong>✅ Domain purchased</strong> - Done!
              </span>
            </div>
            <div className="flex items-center">
              <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
              <span>
                <strong>🔧 Server setup</strong> - 15-20 minutes
              </span>
            </div>
            <div className="flex items-center">
              <div className="w-2 h-2 bg-yellow-500 rounded-full mr-3"></div>
              <span>
                <strong>🌐 DNS propagation</strong> - 5-30 minutes
              </span>
            </div>
            <div className="flex items-center">
              <div className="w-2 h-2 bg-purple-500 rounded-full mr-3"></div>
              <span>
                <strong>🔒 SSL certificates</strong> - 2-5 minutes
              </span>
            </div>
            <div className="flex items-center">
              <div className="w-2 h-2 bg-green-600 rounded-full mr-3"></div>
              <span>
                <strong>🎉 First deployment</strong> - Instantly!
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
