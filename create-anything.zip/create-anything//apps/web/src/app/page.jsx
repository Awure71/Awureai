import { IDE } from "../components/IDE/IDE";

export default function HomePage() {
  return (
    <div className="h-screen bg-white overflow-hidden">
      <IDE />
    </div>
  );
}
