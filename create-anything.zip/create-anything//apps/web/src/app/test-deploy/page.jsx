"use client";

import { useState, useEffect } from "react";
import {
  Rocket,
  CheckCircle,
  AlertCircle,
  ExternalLink,
  Loader2,
} from "lucide-react";

export default function TestDeployPage() {
  const [isDeploying, setIsDeploying] = useState(false);
  const [deployment, setDeployment] = useState(null);
  const [logs, setLogs] = useState([]);
  const [selectedProvider, setSelectedProvider] = useState("awureai-hosting");
  const [providers, setProviders] = useState({});

  useEffect(() => {
    fetchProviders();
  }, []);

  const fetchProviders = async () => {
    try {
      const response = await fetch("/api/deploy?action=providers");
      const data = await response.json();
      setProviders(data.providers || {});
    } catch (error) {
      console.error("Failed to fetch providers:", error);
    }
  };

  const startTestDeploy = async () => {
    setIsDeploying(true);
    setLogs(["🚀 Starting test deployment..."]);
    setDeployment(null);

    try {
      const testFiles = [
        {
          name: "index.html",
          content: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Deployment</title>
    <style>
        body { 
            font-family: system-ui, -apple-system, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            margin: 0;
            text-align: center;
        }
        .container { 
            max-width: 600px; 
            padding: 40px;
            background: rgba(255,255,255,0.1);
            border-radius: 20px;
            backdrop-filter: blur(10px);
        }
        h1 { font-size: 3rem; margin-bottom: 20px; animation: pulse 2s infinite; }
        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 20px; margin-top: 30px; }
        .stat { background: rgba(255,255,255,0.2); padding: 20px; border-radius: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 Test Deployment Success!</h1>
        <p>This is a test deployment from the AwureAI deployment system.</p>
        <div class="stats">
            <div class="stat">
                <h3>Provider</h3>
                <p>${providers[selectedProvider]?.name || selectedProvider}</p>
            </div>
            <div class="stat">
                <h3>Deployed</h3>
                <p>${new Date().toLocaleString()}</p>
            </div>
            <div class="stat">
                <h3>Status</h3>
                <p>✅ Live</p>
            </div>
        </div>
        <script>
            console.log('Test deployment loaded successfully!');
            setTimeout(() => {
                document.body.style.background = 'linear-gradient(135deg, #ff6b6b 0%, #feca57 100%)';
            }, 3000);
        </script>
    </div>
</body>
</html>`,
        },
        {
          name: "style.css",
          content: `/* Test deployment CSS */
body {
  margin: 0;
  font-family: system-ui;
}

.test-element {
  background: #f0f0f0;
  padding: 20px;
  border-radius: 8px;
}`,
        },
        {
          name: "app.js",
          content: `// Test deployment JavaScript
console.log('Test deployment JavaScript loaded!');
console.log('Deployment time:', new Date().toISOString());

document.addEventListener('DOMContentLoaded', function() {
  console.log('DOM loaded, deployment working correctly');
});`,
        },
      ];

      const response = await fetch("/api/deploy", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          projectId: "test-deployment",
          provider: selectedProvider,
          files: testFiles,
          projectName: "Test Deployment",
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        if (data.missingEnvVars) {
          setLogs((prev) => [
            ...prev,
            `❌ Missing environment variables: ${data.missingEnvVars.join(", ")}`,
            `💡 Add ${data.missingEnvVars[0]} to your environment to use ${data.provider}`,
            '🔄 Try using "AwureAI Hosting (Demo)" instead',
          ]);
          setIsDeploying(false);
          return;
        }
        throw new Error(data.error || "Deployment failed");
      }

      setLogs((prev) => [
        ...prev,
        "✅ Deployment request accepted",
        `🆔 Deployment ID: ${data.deployment?.id}`,
        `🌐 Target URL: ${data.deployment?.url}`,
      ]);

      if (data.deployment) {
        setDeployment(data.deployment);
        pollDeploymentStatus();
      }
    } catch (error) {
      console.error("Test deployment failed:", error);
      setLogs((prev) => [
        ...prev,
        "❌ Test deployment failed: " + error.message,
      ]);
      setIsDeploying(false);
    }
  };

  const pollDeploymentStatus = () => {
    const interval = setInterval(async () => {
      try {
        const response = await fetch("/api/deploy?projectId=test-deployment");
        const data = await response.json();

        if (data.deployment) {
          setDeployment(data.deployment);
          setLogs(data.deployment.buildLogs || []);

          if (
            data.deployment.status === "success" ||
            data.deployment.status === "failed"
          ) {
            setIsDeploying(false);
            clearInterval(interval);
          }
        }
      } catch (error) {
        console.error("Failed to poll deployment:", error);
        clearInterval(interval);
        setIsDeploying(false);
      }
    }, 1000);
  };

  const visitDeployment = () => {
    if (deployment?.url) {
      window.open(deployment.url, "_blank");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="p-3 bg-blue-100 rounded-full">
              <Rocket className="text-blue-600" size={32} />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Test Deployment System
          </h1>
          <p className="text-gray-600">
            Test the deployment functionality with a sample project
          </p>
        </div>

        {/* Provider Selection */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            Choose Deployment Provider
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {Object.entries(providers).map(([key, provider]) => (
              <div
                key={key}
                className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                  selectedProvider === key
                    ? "border-blue-500 bg-blue-50"
                    : "border-gray-200 hover:border-gray-300"
                }`}
                onClick={() => setSelectedProvider(key)}
              >
                <div className="flex items-center space-x-3">
                  <span className="text-2xl">{provider.icon}</span>
                  <div>
                    <h3 className="font-medium text-gray-900">
                      {provider.name}
                    </h3>
                    <p className="text-sm text-gray-600">
                      {provider.description}
                    </p>
                    {provider.requiresAuth && (
                      <p className="text-xs text-orange-600 mt-1">
                        Requires setup
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <button
            onClick={startTestDeploy}
            disabled={isDeploying}
            className={`w-full mt-6 py-3 px-4 rounded-lg font-medium transition-colors ${
              !isDeploying
                ? "bg-blue-600 hover:bg-blue-700 text-white"
                : "bg-gray-300 text-gray-500 cursor-not-allowed"
            }`}
          >
            {isDeploying ? "Deploying..." : "Start Test Deployment"}
          </button>
        </div>

        {/* Deployment Status */}
        {(deployment || isDeploying) && (
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <div className="flex items-center space-x-3 mb-4">
              {deployment?.status === "success" && (
                <>
                  <CheckCircle className="text-green-600" size={24} />
                  <span className="text-green-600 font-medium">
                    Deployment Successful!
                  </span>
                </>
              )}
              {deployment?.status === "building" && (
                <>
                  <Loader2 className="text-blue-600 animate-spin" size={24} />
                  <span className="text-blue-600 font-medium">
                    Deploying...
                  </span>
                </>
              )}
              {deployment?.status === "failed" && (
                <>
                  <AlertCircle className="text-red-600" size={24} />
                  <span className="text-red-600 font-medium">
                    Deployment Failed
                  </span>
                </>
              )}
            </div>

            {/* URL Display */}
            {deployment?.url && (
              <div className="bg-gray-50 p-4 rounded-lg mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Deployment URL
                </label>
                <div className="flex items-center space-x-2">
                  <input
                    type="text"
                    value={deployment.url}
                    readOnly
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-md bg-white text-sm"
                  />
                  <button
                    onClick={visitDeployment}
                    className="flex items-center space-x-1 px-3 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors text-sm"
                  >
                    <ExternalLink size={16} />
                    <span>Visit</span>
                  </button>
                </div>
              </div>
            )}

            {/* Build Logs */}
            <div className="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm max-h-64 overflow-y-auto">
              {logs.map((log, index) => (
                <div key={index} className="mb-1">
                  {log}
                </div>
              ))}
              {isDeploying && (
                <div className="flex items-center space-x-2 text-blue-400">
                  <Loader2 size={14} className="animate-spin" />
                  <span>Processing...</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Test Info */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h3 className="text-blue-900 font-medium mb-2">
            What this test does:
          </h3>
          <ul className="list-disc list-inside text-sm text-blue-800 space-y-1">
            <li>Creates 3 test files (HTML, CSS, JavaScript)</li>
            <li>Tests the selected deployment provider</li>
            <li>Shows real-time deployment logs</li>
            <li>Provides a live URL to visit the deployed test site</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
