// Git integration API for AwureAI IDE
let gitRepositories = new Map();
let gitCommits = new Map();

export async function GET(request) {
  try {
    const url = new URL(request.url);
    const projectId = url.searchParams.get("projectId") || "default";
    const action = url.searchParams.get("action");

    const repo = gitRepositories.get(projectId) || {
      initialized: false,
      branches: ["main"],
      currentBranch: "main",
      remotes: [],
      commits: [],
      status: [],
    };

    if (action === "status") {
      return Response.json({
        branch: repo.currentBranch,
        staged: repo.status.filter((f) => f.staged),
        modified: repo.status.filter(
          (f) => !f.staged && f.status === "modified",
        ),
        untracked: repo.status.filter(
          (f) => !f.staged && f.status === "untracked",
        ),
        ahead: repo.ahead || 0,
        behind: repo.behind || 0,
      });
    }

    if (action === "log") {
      const commits = gitCommits.get(projectId) || [];
      return Response.json({ commits: commits.slice(0, 10) });
    }

    if (action === "branches") {
      return Response.json({
        branches: repo.branches,
        current: repo.currentBranch,
        remotes: repo.remotes,
      });
    }

    return Response.json(repo);
  } catch (error) {
    return Response.json({ error: "Git operation failed" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const {
      projectId = "default",
      command,
      args = [],
      message,
      files,
    } = await request.json();

    let repo = gitRepositories.get(projectId) || {
      initialized: false,
      branches: ["main"],
      currentBranch: "main",
      remotes: [],
      commits: [],
      status: [],
    };

    let commits = gitCommits.get(projectId) || [];
    let output = "";

    switch (command) {
      case "init":
        repo.initialized = true;
        repo.status = files
          ? files.map((f) => ({
              name: f.name,
              status: "untracked",
              staged: false,
            }))
          : [];
        output = "Initialized empty Git repository";
        break;

      case "add":
        if (args.includes(".")) {
          repo.status.forEach((file) => (file.staged = true));
          output = `Added ${repo.status.length} files to staging area`;
        } else {
          args.forEach((filename) => {
            const file = repo.status.find((f) => f.name === filename);
            if (file) file.staged = true;
          });
          output = `Added ${args.join(", ")} to staging area`;
        }
        break;

      case "commit":
        const stagedFiles = repo.status.filter((f) => f.staged);
        if (stagedFiles.length === 0) {
          return Response.json(
            { error: "No staged files to commit" },
            { status: 400 },
          );
        }

        const commit = {
          id: Math.random().toString(36).substring(7),
          message: message || "Updated files",
          author: "AwureAI Developer",
          date: new Date().toISOString(),
          files: stagedFiles.map((f) => f.name),
          branch: repo.currentBranch,
        };

        commits.unshift(commit);
        repo.status.forEach((f) => (f.staged = false));
        repo.status = repo.status.map((f) => ({ ...f, status: "clean" }));

        output = `[${repo.currentBranch} ${commit.id}] ${commit.message}\n${stagedFiles.length} files changed`;
        break;

      case "branch":
        if (args.length > 0) {
          const newBranch = args[0];
          if (!repo.branches.includes(newBranch)) {
            repo.branches.push(newBranch);
            output = `Created branch '${newBranch}'`;
          } else {
            output = `Branch '${newBranch}' already exists`;
          }
        } else {
          output = repo.branches
            .map((b) => (b === repo.currentBranch ? `* ${b}` : `  ${b}`))
            .join("\n");
        }
        break;

      case "checkout":
        if (args.length > 0) {
          const branch = args[0];
          if (repo.branches.includes(branch)) {
            repo.currentBranch = branch;
            output = `Switched to branch '${branch}'`;
          } else {
            return Response.json(
              { error: `Branch '${branch}' not found` },
              { status: 400 },
            );
          }
        }
        break;

      case "push":
        const remote = args[0] || "origin";
        const branch = args[1] || repo.currentBranch;

        if (!repo.remotes.find((r) => r.name === remote)) {
          return Response.json(
            { error: `Remote '${remote}' not found. Add remote first.` },
            { status: 400 },
          );
        }

        output = `Pushed ${commits.length} commits to ${remote}/${branch}`;
        repo.ahead = 0;
        break;

      case "pull":
        const pullRemote = args[0] || "origin";
        const pullBranch = args[1] || repo.currentBranch;
        output = `Already up to date from ${pullRemote}/${pullBranch}`;
        repo.behind = 0;
        break;

      case "remote":
        if (args[0] === "add") {
          const remoteName = args[1];
          const remoteUrl = args[2];
          if (remoteName && remoteUrl) {
            repo.remotes.push({ name: remoteName, url: remoteUrl });
            output = `Added remote '${remoteName}'`;
          }
        } else {
          output =
            repo.remotes.map((r) => `${r.name}\t${r.url}`).join("\n") ||
            "No remotes configured";
        }
        break;

      case "clone":
        const cloneUrl = args[0];
        if (cloneUrl) {
          repo.initialized = true;
          repo.remotes.push({ name: "origin", url: cloneUrl });
          output = `Cloned repository from ${cloneUrl}`;
        }
        break;

      default:
        return Response.json(
          { error: `Unknown git command: ${command}` },
          { status: 400 },
        );
    }

    gitRepositories.set(projectId, repo);
    gitCommits.set(projectId, commits);

    return Response.json({
      output,
      repo: {
        branch: repo.currentBranch,
        initialized: repo.initialized,
        ahead: repo.ahead || 0,
        behind: repo.behind || 0,
      },
    });
  } catch (error) {
    console.error("Git operation error:", error);
    return Response.json({ error: "Git operation failed" }, { status: 500 });
  }
}
