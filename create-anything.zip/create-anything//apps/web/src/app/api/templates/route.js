// Project templates for AwureAI IDE - like Replit templates

const APP_TEMPLATES = {
  "vanilla-js": {
    id: "vanilla-js",
    name: "Vanilla JavaScript",
    description: "Basic HTML, CSS, and JavaScript project",
    category: "web",
    language: "javascript",
    icon: "🟨",
    files: [
      {
        name: "index.html",
        type: "file",
        content: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Awesome App</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Welcome to AwureAI!</h1>
        <p>Start building your amazing app here.</p>
        <button id="clickBtn">Click me!</button>
        <div id="output"></div>
    </div>
    <script src="script.js"></script>
</body>
</html>`,
        language: "html",
      },
      {
        name: "style.css",
        type: "file",
        content: `body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    margin: 0;
    padding: 20px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    min-height: 100vh;
}

.container {
    max-width: 600px;
    margin: 0 auto;
    text-align: center;
    padding: 2rem;
}

h1 {
    font-size: 3rem;
    margin-bottom: 1rem;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
}

button {
    background: #ff6b6b;
    color: white;
    border: none;
    padding: 12px 24px;
    font-size: 1.1rem;
    border-radius: 25px;
    cursor: pointer;
    transition: all 0.3s ease;
}

button:hover {
    background: #ff5252;
    transform: translateY(-2px);
}`,
        language: "css",
      },
      {
        name: "script.js",
        type: "file",
        content: `// Welcome to your AwureAI project!

const btn = document.getElementById('clickBtn');
const output = document.getElementById('output');

let clickCount = 0;

btn.addEventListener('click', () => {
    clickCount++;
    output.innerHTML = \`
        <h3>Button clicked \${clickCount} time(s)!</h3>
        <p>Time: \${new Date().toLocaleTimeString()}</p>
    \`;
    
    console.log('Button clicked!', clickCount);
});

console.log('App initialized successfully!');`,
        language: "javascript",
      },
    ],
  },

  "react-app": {
    id: "react-app",
    name: "React App",
    description: "Modern React application with components",
    category: "web",
    language: "javascript",
    icon: "⚛️",
    files: [
      {
        name: "App.jsx",
        type: "file",
        content: `import React, { useState } from 'react';

function App() {
  const [count, setCount] = useState(0);
  const [name, setName] = useState('');

  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial, sans-serif' }}>
      <h1>Welcome to AwureAI React App!</h1>
      
      <div style={{ marginBottom: '2rem' }}>
        <h2>Counter: {count}</h2>
        <button onClick={() => setCount(count + 1)}>
          Increment
        </button>
        <button onClick={() => setCount(count - 1)} style={{ marginLeft: '10px' }}>
          Decrement
        </button>
      </div>

      <div>
        <h3>What's your name?</h3>
        <input 
          type="text" 
          value={name} 
          onChange={(e) => setName(e.target.value)}
          placeholder="Enter your name"
          style={{ padding: '8px', fontSize: '16px' }}
        />
        {name && <p>Hello, {name}! 👋</p>}
      </div>
    </div>
  );
}

export default App;`,
        language: "javascript",
      },
    ],
  },
};

export async function GET(request) {
  try {
    const url = new URL(request.url);
    const templateId = url.searchParams.get("id");
    const category = url.searchParams.get("category") || "";

    if (templateId) {
      const template = APP_TEMPLATES[templateId];
      if (!template) {
        return Response.json({ error: "Template not found" }, { status: 404 });
      }
      return Response.json(template);
    }

    // Return all templates or filtered by category
    let templates = Object.values(APP_TEMPLATES);
    if (category && category !== "all") {
      templates = templates.filter(
        (template) => template.category === category,
      );
    }

    return Response.json({
      templates,
      categories: ["all", "web", "api", "mobile", "game", "data"],
    });
  } catch (error) {
    return Response.json(
      { error: "Failed to fetch templates" },
      { status: 500 },
    );
  }
}
