// Simple in-memory storage for demo purposes
// In a real app, this would use a database
let projects = [
  {
    id: "1",
    name: "awureai-demo-app",
    description: "Welcome to AwureAI - Your powerful online IDE",
    language: "javascript",
    createdAt: new Date().toISOString(),
    files: [
      {
        id: "1",
        name: "index.html",
        type: "file",
        content: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AwureAI Demo App</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="logo">
                <div class="logo-icon">A</div>
                <h1>AwureAI</h1>
            </div>
            <p class="tagline">Build anything, anywhere</p>
        </div>
        
        <div class="features">
            <div class="feature-card">
                <h3>🚀 Multiple Languages</h3>
                <p>JavaScript, Python, HTML, CSS, JSON, Markdown</p>
            </div>
            <div class="feature-card">
                <h3>⚡ Live Execution</h3>
                <p>Run your code instantly and see results</p>
            </div>
            <div class="feature-card">
                <h3>🎨 Beautiful Editor</h3>
                <p>Syntax highlighting, auto-completion, search</p>
            </div>
        </div>
        
        <div class="demo-section">
            <h2>Interactive Demo</h2>
            <button id="demoBtn" class="demo-btn">Try Interactive Features</button>
            <div id="output" class="output-area"></div>
        </div>
    </div>
    <script src="script.js"></script>
</body>
</html>`,
        language: "html",
      },
      {
        id: "2",
        name: "style.css",
        type: "file",
        content: `body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  margin: 0;
  padding: 20px;
  min-height: 100vh;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
}

.header {
  text-align: center;
  margin-bottom: 3rem;
}

.logo {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1rem;
  margin-bottom: 1rem;
}

.logo-icon {
  width: 60px;
  height: 60px;
  background: linear-gradient(45deg, #ff6b6b, #ffa726);
  border-radius: 15px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 2rem;
  font-weight: bold;
  color: white;
  box-shadow: 0 10px 25px rgba(0,0,0,0.2);
}

.logo h1 {
  font-size: 3.5rem;
  background: linear-gradient(45deg, #ff6b6b, #ffa726);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.features {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
  margin-bottom: 3rem;
}

.feature-card {
  background: rgba(255,255,255,0.1);
  backdrop-filter: blur(10px);
  border-radius: 15px;
  padding: 2rem;
  text-align: center;
  border: 1px solid rgba(255,255,255,0.2);
  transition: transform 0.3s ease;
}

.feature-card:hover {
  transform: translateY(-5px);
}

.demo-section {
  text-align: center;
  background: rgba(255,255,255,0.1);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  padding: 3rem;
}

.demo-btn {
  background: linear-gradient(45deg, #ff6b6b, #ffa726);
  color: white;
  border: none;
  padding: 15px 30px;
  font-size: 1.1rem;
  border-radius: 50px;
  cursor: pointer;
  margin-bottom: 2rem;
}

.output-area {
  min-height: 100px;
  background: rgba(0,0,0,0.2);
  border-radius: 10px;
  padding: 1rem;
  text-align: left;
  font-family: 'Monaco', monospace;
}`,
        language: "css",
      },
      {
        id: "3",
        name: "script.js",
        type: "file",
        content: `// AwureAI Demo Application
console.log('🚀 AwureAI Demo App Started!');

const demoBtn = document.getElementById('demoBtn');
const output = document.getElementById('output');

let demoCount = 0;
const demoFeatures = [
    'Auto-completion and syntax highlighting',
    'Multi-language support (JS, Python, HTML, CSS)',
    'Live code execution and debugging',
    'Package management system',
    'Project templates and scaffolding',
    'Real-time collaboration (coming soon)',
    'Git integration and version control',
    'Cloud deployment and hosting'
];

demoBtn.addEventListener('click', () => {
    demoCount++;
    
    const randomFeature = demoFeatures[Math.floor(Math.random() * demoFeatures.length)];
    const timestamp = new Date().toLocaleTimeString();
    
    output.innerHTML += \`
        <div style="margin-bottom: 10px; padding: 10px; background: rgba(255,255,255,0.1); border-radius: 5px;">
            <strong>Demo #\${demoCount}</strong> - \${timestamp}
            <br>✨ Feature: \${randomFeature}
            <br>🎯 Status: Ready for development!
        </div>
    \`;
    
    console.log(\`Demo executed: \${randomFeature}\`);
});

// Welcome message
setTimeout(() => {
    output.innerHTML = \`
        <div style="color: #4ade80; font-weight: bold;">
            ✅ AwureAI IDE initialized successfully!
        </div>
        <div style="margin-top: 10px; color: #fbbf24;">
            🎯 Ready to build your next amazing project
        </div>
        <div style="margin-top: 10px; color: #60a5fa;">
            👆 Click the button above to see interactive features
        </div>
    \`;
}, 1000);

console.log('Welcome to AwureAI - where ideas become reality! 🌟');`,
        language: "javascript",
      },
      {
        id: "4",
        name: "README.md",
        type: "file",
        content: `# AwureAI Demo Project

Welcome to AwureAI - your powerful online IDE! 🚀

## Features

- **Multi-language support**: JavaScript, Python, HTML, CSS, JSON, Markdown
- **Live code execution**: Run your code instantly
- **Advanced editor**: Syntax highlighting, auto-completion, search
- **Package management**: Install and manage dependencies
- **App building**: Create web apps, APIs, and more

## Getting Started

1. Select files from the explorer
2. Edit code with advanced features
3. Run your code with the Run button
4. See results in the terminal

Built with ❤️ by AwureAI Team`,
        language: "markdown",
      },
    ],
  },
];

export async function GET(request) {
  try {
    const url = new URL(request.url);
    const projectId = url.searchParams.get("id");

    if (projectId) {
      const project = projects.find((p) => p.id === projectId);
      if (!project) {
        return Response.json({ error: "Project not found" }, { status: 404 });
      }
      return Response.json(project);
    }

    // Return all projects
    return Response.json(projects);
  } catch (error) {
    return Response.json(
      { error: "Failed to fetch projects" },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const { name, description, language = "javascript" } = await request.json();

    if (!name) {
      return Response.json(
        { error: "Project name is required" },
        { status: 400 },
      );
    }

    const newProject = {
      id: Date.now().toString(),
      name,
      description: description || "",
      language,
      createdAt: new Date().toISOString(),
      files: [
        {
          id: Date.now().toString(),
          name: language === "python" ? "main.py" : "index.js",
          type: "file",
          content:
            language === "python"
              ? 'print("Hello, World!")\n\ndef greet(name):\n    return f"Hello, {name}!"\n\nprint(greet("Developer"))'
              : 'console.log("Hello, World!");\n\nfunction greet(name) {\n  return `Hello, ${name}!`;\n}\n\nconsole.log(greet("Developer"));',
          language,
        },
      ],
    };

    projects.push(newProject);
    return Response.json(newProject, { status: 201 });
  } catch (error) {
    return Response.json(
      { error: "Failed to create project" },
      { status: 500 },
    );
  }
}

export async function PUT(request) {
  try {
    const { id, files } = await request.json();

    if (!id) {
      return Response.json(
        { error: "Project ID is required" },
        { status: 400 },
      );
    }

    const projectIndex = projects.findIndex((p) => p.id === id);
    if (projectIndex === -1) {
      return Response.json({ error: "Project not found" }, { status: 404 });
    }

    if (files) {
      projects[projectIndex].files = files;
    }

    return Response.json(projects[projectIndex]);
  } catch (error) {
    return Response.json(
      { error: "Failed to update project" },
      { status: 500 },
    );
  }
}
