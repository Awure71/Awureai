// Package management system for AwureAI IDE
let projectPackages = new Map();

// Popular packages database
const POPULAR_PACKAGES = {
  react: {
    name: "react",
    version: "18.2.0",
    description: "A JavaScript library for building user interfaces",
    category: "frontend",
    homepage: "https://reactjs.org",
  },
  express: {
    name: "express",
    version: "4.18.2",
    description: "Fast, unopinionated, minimalist web framework for Node.js",
    category: "backend",
    homepage: "https://expressjs.com",
  },
  lodash: {
    name: "lodash",
    version: "4.17.21",
    description: "A modern JavaScript utility library",
    category: "utility",
    homepage: "https://lodash.com",
  },
  axios: {
    name: "axios",
    version: "1.6.0",
    description: "Promise based HTTP client for the browser and node.js",
    category: "utility",
    homepage: "https://axios-http.com",
  },
  vue: {
    name: "vue",
    version: "3.3.4",
    description: "Progressive JavaScript framework",
    category: "frontend",
    homepage: "https://vuejs.org",
  },
  tailwindcss: {
    name: "tailwindcss",
    version: "3.3.0",
    description: "A utility-first CSS framework",
    category: "styling",
    homepage: "https://tailwindcss.com",
  },
  typescript: {
    name: "typescript",
    version: "5.2.2",
    description: "TypeScript is a language for application-scale JavaScript",
    category: "language",
    homepage: "https://www.typescriptlang.org",
  },
  next: {
    name: "next",
    version: "13.5.6",
    description: "The React Framework",
    category: "framework",
    homepage: "https://nextjs.org",
  },
};

export async function GET(request) {
  try {
    const url = new URL(request.url);
    const projectId = url.searchParams.get("projectId") || "default";
    const search = url.searchParams.get("search") || "";
    const category = url.searchParams.get("category") || "";

    // Get installed packages for project
    const installedPackages = projectPackages.get(projectId) || [];

    // Search popular packages
    let availablePackages = Object.values(POPULAR_PACKAGES);

    if (search) {
      availablePackages = availablePackages.filter(
        (pkg) =>
          pkg.name.toLowerCase().includes(search.toLowerCase()) ||
          pkg.description.toLowerCase().includes(search.toLowerCase()),
      );
    }

    if (category && category !== "all") {
      availablePackages = availablePackages.filter(
        (pkg) => pkg.category === category,
      );
    }

    return Response.json({
      installed: installedPackages,
      available: availablePackages,
      categories: [
        "all",
        "frontend",
        "backend",
        "utility",
        "styling",
        "language",
        "framework",
      ],
    });
  } catch (error) {
    return Response.json(
      { error: "Failed to fetch packages" },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const { projectId = "default", packageName, action } = await request.json();

    if (!packageName || !action) {
      return Response.json(
        { error: "Package name and action required" },
        { status: 400 },
      );
    }

    const installedPackages = projectPackages.get(projectId) || [];

    if (action === "install") {
      // Check if package exists in popular packages
      const packageInfo = POPULAR_PACKAGES[packageName];
      if (!packageInfo) {
        return Response.json({ error: "Package not found" }, { status: 404 });
      }

      // Check if already installed
      const isInstalled = installedPackages.some(
        (pkg) => pkg.name === packageName,
      );
      if (isInstalled) {
        return Response.json(
          { error: "Package already installed" },
          { status: 400 },
        );
      }

      // Add to installed packages
      const newPackage = {
        ...packageInfo,
        installedAt: new Date().toISOString(),
        status: "installed",
      };

      projectPackages.set(projectId, [...installedPackages, newPackage]);

      return Response.json({
        message: `Package ${packageName} installed successfully`,
        package: newPackage,
        installed: projectPackages.get(projectId),
      });
    } else if (action === "uninstall") {
      const updatedPackages = installedPackages.filter(
        (pkg) => pkg.name !== packageName,
      );
      projectPackages.set(projectId, updatedPackages);

      return Response.json({
        message: `Package ${packageName} uninstalled successfully`,
        installed: updatedPackages,
      });
    } else {
      return Response.json({ error: "Invalid action" }, { status: 400 });
    }
  } catch (error) {
    console.error("Package management error:", error);
    return Response.json(
      { error: "Package operation failed" },
      { status: 500 },
    );
  }
}

export async function PUT(request) {
  try {
    const { projectId = "default", packageName } = await request.json();

    if (!packageName) {
      return Response.json({ error: "Package name required" }, { status: 400 });
    }

    const installedPackages = projectPackages.get(projectId) || [];
    const packageIndex = installedPackages.findIndex(
      (pkg) => pkg.name === packageName,
    );

    if (packageIndex === -1) {
      return Response.json({ error: "Package not found" }, { status: 404 });
    }

    // Update package (simulate getting latest version)
    const latestInfo = POPULAR_PACKAGES[packageName];
    if (latestInfo) {
      installedPackages[packageIndex] = {
        ...installedPackages[packageIndex],
        version: latestInfo.version,
        updatedAt: new Date().toISOString(),
      };
    }

    projectPackages.set(projectId, installedPackages);

    return Response.json({
      message: `Package ${packageName} updated successfully`,
      package: installedPackages[packageIndex],
      installed: installedPackages,
    });
  } catch (error) {
    console.error("Package update error:", error);
    return Response.json({ error: "Package update failed" }, { status: 500 });
  }
}
