// Static file serving for AwureAI hosted deployments
import sql from "@/app/api/utils/sql";

export async function GET(request, { params }) {
  try {
    const { path } = params;
    const url = new URL(request.url);
    const host = request.headers.get("host") || url.hostname;

    // Extract subdomain from host (remove .awureai.app)
    const subdomain = host
      .replace(".awureai.app", "")
      .replace(".localhost:3000", "");

    if (!subdomain) {
      return new Response("Subdomain not found", { status: 404 });
    }

    // Find deployment by subdomain
    const [deployment] = await sql`
      SELECT * FROM hosting_deployments 
      WHERE subdomain = ${subdomain} AND status = 'success'
    `;

    if (!deployment) {
      return new Response(
        `
<!DOCTYPE html>
<html>
<head>
  <title>Site Not Found - AwureAI</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body { 
      font-family: system-ui, -apple-system, sans-serif;
      text-align: center; 
      padding: 100px 20px; 
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      margin: 0;
    }
    .container {
      max-width: 600px;
      margin: 0 auto;
      background: rgba(255,255,255,0.1);
      padding: 40px;
      border-radius: 20px;
      backdrop-filter: blur(10px);
    }
    h1 { font-size: 3rem; margin-bottom: 20px; }
    p { font-size: 1.2rem; margin-bottom: 30px; }
    .code { 
      background: rgba(0,0,0,0.3); 
      padding: 15px; 
      border-radius: 8px; 
      font-family: monospace; 
      font-size: 1rem;
      word-break: break-all;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>🔍 Site Not Found</h1>
    <p>The deployment for <strong>${subdomain}.awureai.app</strong> could not be found.</p>
    <div class="code">subdomain: ${subdomain}</div>
    <p style="margin-top: 30px; font-size: 1rem; opacity: 0.8;">
      This could mean the deployment was deleted, failed, or hasn't completed yet.
    </p>
  </div>
</body>
</html>
      `,
        {
          status: 404,
          headers: {
            "Content-Type": "text/html",
          },
        },
      );
    }

    // Get the requested file path
    const requestedPath = path ? path.join("/") : "index.html";
    let filePath = requestedPath;

    // If no extension and not ending with /, try adding index.html
    if (!filePath.includes(".") && !filePath.endsWith("/")) {
      filePath = filePath + "/index.html";
    }

    // If ends with /, add index.html
    if (filePath.endsWith("/")) {
      filePath = filePath + "index.html";
    }

    // Remove leading slash
    if (filePath.startsWith("/")) {
      filePath = filePath.substring(1);
    }

    // Find the specific file
    let [file] = await sql`
      SELECT * FROM hosting_files 
      WHERE deployment_id = ${deployment.deployment_id} 
      AND file_path = ${filePath}
    `;

    // If not found and it's a path without extension, try with index.html
    if (!file && !filePath.includes(".")) {
      const indexPath =
        filePath === "" ? "index.html" : `${filePath}/index.html`;
      [file] = await sql`
        SELECT * FROM hosting_files 
        WHERE deployment_id = ${deployment.deployment_id} 
        AND file_path = ${indexPath}
      `;
    }

    // If still not found, try just index.html
    if (!file) {
      [file] = await sql`
        SELECT * FROM hosting_files 
        WHERE deployment_id = ${deployment.deployment_id} 
        AND file_path = 'index.html'
      `;
    }

    if (!file) {
      return new Response(
        `
<!DOCTYPE html>
<html>
<head>
  <title>File Not Found - ${deployment.project_name}</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body { 
      font-family: system-ui, -apple-system, sans-serif;
      text-align: center; 
      padding: 100px 20px; 
      background: #f8f9fa;
      color: #333;
      margin: 0;
    }
    .container {
      max-width: 600px;
      margin: 0 auto;
      background: white;
      padding: 40px;
      border-radius: 12px;
      box-shadow: 0 4px 24px rgba(0,0,0,0.1);
    }
    h1 { color: #e74c3c; margin-bottom: 20px; }
    .code { 
      background: #f8f9fa; 
      padding: 15px; 
      border-radius: 8px; 
      font-family: monospace; 
      border: 1px solid #dee2e6;
      margin: 20px 0;
    }
    .meta {
      background: #e3f2fd;
      padding: 20px;
      border-radius: 8px;
      margin-top: 30px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>📄 File Not Found</h1>
    <p>The file <strong>${filePath}</strong> was not found in this deployment.</p>
    
    <div class="code">
      Requested: ${requestedPath}<br>
      Looking for: ${filePath}
    </div>

    <div class="meta">
      <h3>${deployment.project_name}</h3>
      <p>Deployed: ${new Date(deployment.deployed_at).toLocaleString()}</p>
      <p>Files: ${deployment.file_count} total</p>
    </div>
  </div>
</body>
</html>
      `,
        {
          status: 404,
          headers: {
            "Content-Type": "text/html",
          },
        },
      );
    }

    // Serve the file
    const headers = {
      "Content-Type": file.content_type || "text/plain",
      "Cache-Control": "public, max-age=3600",
      "X-Deployment-ID": deployment.deployment_id,
      "X-File-Path": file.file_path,
    };

    return new Response(file.file_content, {
      status: 200,
      headers,
    });
  } catch (error) {
    console.error("Hosting serve error:", error);

    return new Response(
      `
<!DOCTYPE html>
<html>
<head>
  <title>Server Error - AwureAI</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body { 
      font-family: system-ui, -apple-system, sans-serif;
      text-align: center; 
      padding: 100px 20px; 
      background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
      color: white;
      margin: 0;
    }
    .container {
      max-width: 600px;
      margin: 0 auto;
      background: rgba(255,255,255,0.1);
      padding: 40px;
      border-radius: 20px;
      backdrop-filter: blur(10px);
    }
    h1 { font-size: 3rem; margin-bottom: 20px; }
    .error { 
      background: rgba(0,0,0,0.3); 
      padding: 15px; 
      border-radius: 8px; 
      font-family: monospace; 
      margin: 20px 0;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>⚠️ Server Error</h1>
    <p>Something went wrong while serving this file.</p>
    <div class="error">${error.message}</div>
    <p style="font-size: 1rem; opacity: 0.8;">
      Please try again later or contact support.
    </p>
  </div>
</body>
</html>
    `,
      {
        status: 500,
        headers: {
          "Content-Type": "text/html",
        },
      },
    );
  }
}
