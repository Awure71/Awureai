// Real Deployment API for AwureAI IDE
let deployments = new Map();
let deploymentHistory = new Map();

const DEPLOYMENT_PROVIDERS = {
  vercel: {
    name: "Vercel",
    description: "Deploy to Vercel with automatic builds",
    supports: ["react", "nextjs", "vanilla-js", "static"],
    icon: "▲",
    buildCommand: "npm run build",
    outputDir: "dist",
    requiresAuth: true,
    envVars: ["VERCEL_TOKEN"],
  },
  netlify: {
    name: "Netlify",
    description: "Deploy to Netlify with continuous deployment",
    supports: ["react", "vue", "vanilla-js", "static"],
    icon: "🚀",
    buildCommand: "npm run build",
    outputDir: "build",
    requiresAuth: true,
    envVars: ["NETLIFY_TOKEN"],
  },
  "github-pages": {
    name: "GitHub Pages",
    description: "Deploy static sites to GitHub Pages",
    supports: ["static", "vanilla-js"],
    icon: "🐙",
    buildCommand: null,
    outputDir: null,
    requiresAuth: true,
    envVars: ["GITHUB_TOKEN"],
  },
  "awureai-hosting": {
    name: "AwureAI Hosting (Demo)",
    description: "Simulated deployment for demo purposes",
    supports: ["all"],
    icon: "⚡",
    buildCommand: null,
    outputDir: null,
    requiresAuth: false,
    envVars: [],
  },
  "awureai-real": {
    name: "AwureAI Hosting",
    description: "Deploy to AwureAI's real hosting infrastructure",
    supports: ["static", "spa", "vanilla-js"],
    icon: "🔥",
    buildCommand: null,
    outputDir: null,
    requiresAuth: false,
    envVars: [],
  },
};

export async function GET(request) {
  try {
    const url = new URL(request.url);
    const projectId = url.searchParams.get("projectId");
    const action = url.searchParams.get("action");

    if (action === "providers") {
      return Response.json({ providers: DEPLOYMENT_PROVIDERS });
    }

    if (action === "history" && projectId) {
      const history = deploymentHistory.get(projectId) || [];
      return Response.json({ history });
    }

    if (projectId) {
      const deployment = deployments.get(projectId);
      return Response.json({ deployment: deployment || null });
    }

    // Return all deployments
    const allDeployments = Array.from(deployments.entries()).map(
      ([id, deployment]) => ({
        projectId: id,
        ...deployment,
      }),
    );

    return Response.json({ deployments: allDeployments });
  } catch (error) {
    return Response.json(
      { error: "Failed to fetch deployment info" },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const {
      projectId,
      provider,
      config = {},
      files,
      envVars = {},
      projectName,
    } = await request.json();

    if (!projectId || !provider || !files) {
      return Response.json(
        {
          error: "Project ID, provider, and files are required",
        },
        { status: 400 },
      );
    }

    const providerConfig = DEPLOYMENT_PROVIDERS[provider];
    if (!providerConfig) {
      return Response.json(
        { error: "Invalid deployment provider" },
        { status: 400 },
      );
    }

    // Check for required environment variables
    const missingEnvVars = providerConfig.envVars.filter(
      (envVar) => !process.env[envVar],
    );

    if (missingEnvVars.length > 0) {
      return Response.json(
        {
          error: `Missing required environment variables: ${missingEnvVars.join(", ")}`,
          missingEnvVars,
          provider: providerConfig.name,
        },
        { status: 400 },
      );
    }

    // Generate deployment ID and URL
    const deploymentId = `${provider}-${Date.now().toString(36)}`;

    // Create deployment record
    const deployment = {
      id: deploymentId,
      provider,
      providerName: providerConfig.name,
      url: generateDeploymentUrl(
        provider,
        projectName || projectId,
        deploymentId,
      ), // Set URL immediately
      status: "building",
      createdAt: new Date().toISOString(),
      config,
      envVars: Object.keys(envVars).length > 0 ? envVars : null,
      buildLogs: [],
    };

    // Add to deployment tracking
    deployments.set(projectId, deployment);

    // Start actual deployment process
    if (provider === "awureai-hosting") {
      // Keep simulation for demo provider
      simulateDeployment(projectId, deployment, files, providerConfig);
    } else if (provider === "awureai-real") {
      // Deploy to real AwureAI hosting infrastructure
      deployToAwureAIReal(
        projectId,
        deployment,
        files,
        providerConfig,
        projectName || projectId,
      );
    } else {
      // Real deployment to third-party providers
      realDeployment(
        projectId,
        deployment,
        files,
        providerConfig,
        projectName || projectId,
      );
    }

    return Response.json({
      deployment,
      message: `Starting deployment to ${providerConfig.name}...`,
    });
  } catch (error) {
    console.error("Deployment error:", error);
    return Response.json({ error: "Deployment failed" }, { status: 500 });
  }
}

export async function PUT(request) {
  try {
    const { projectId, action } = await request.json();

    if (!projectId) {
      return Response.json({ error: "Project ID required" }, { status: 400 });
    }

    const deployment = deployments.get(projectId);
    if (!deployment) {
      return Response.json({ error: "No deployment found" }, { status: 404 });
    }

    if (action === "redeploy") {
      deployment.status = "building";
      deployment.redeployedAt = new Date().toISOString();
      deployment.buildLogs = ["🔄 Starting redeployment..."];

      // Simulate redeployment
      setTimeout(() => {
        deployment.status = "success";
        deployment.buildLogs.push("✅ Redeployment successful");
        deployment.deployedAt = new Date().toISOString();
      }, 3000);

      return Response.json({
        deployment,
        message: "Redeployment started",
      });
    }

    return Response.json({ error: "Invalid action" }, { status: 400 });
  } catch (error) {
    return Response.json({ error: "Update failed" }, { status: 500 });
  }
}

export async function DELETE(request) {
  try {
    const { projectId } = await request.json();

    if (!projectId) {
      return Response.json({ error: "Project ID required" }, { status: 400 });
    }

    const deployment = deployments.get(projectId);
    if (!deployment) {
      return Response.json({ error: "No deployment found" }, { status: 404 });
    }

    // Add to history before deletion
    const history = deploymentHistory.get(projectId) || [];
    history.unshift({
      ...deployment,
      deletedAt: new Date().toISOString(),
    });
    deploymentHistory.set(projectId, history.slice(0, 10)); // Keep last 10

    // Remove active deployment
    deployments.delete(projectId);

    return Response.json({
      message: "Deployment deleted successfully",
    });
  } catch (error) {
    return Response.json({ error: "Deletion failed" }, { status: 500 });
  }
}

// Real deployment functions
async function realDeployment(
  projectId,
  deployment,
  files,
  providerConfig,
  projectName,
) {
  const logs = deployment.buildLogs;

  try {
    logs.push("📦 Preparing files for deployment...");
    deployment.buildLogs = [...logs];
    deployments.set(projectId, deployment);

    let deploymentUrl;

    // Add timeout wrapper
    const deploymentPromise = new Promise(async (resolve, reject) => {
      try {
        switch (deployment.provider) {
          case "vercel":
            deploymentUrl = await deployToVercel(
              files,
              projectName,
              logs,
              deployment,
              projectId,
            );
            break;
          case "netlify":
            deploymentUrl = await deployToNetlify(
              files,
              projectName,
              logs,
              deployment,
              projectId,
            );
            break;
          case "github-pages":
            deploymentUrl = await deployToGitHubPages(
              files,
              projectName,
              logs,
              deployment,
              projectId,
            );
            break;
          case "awureai-real":
            deploymentUrl = await deployToAwureAIReal(
              projectId,
              deployment,
              files,
              providerConfig,
              projectName,
            );
            break;
          default:
            throw new Error(
              `Deployment to ${deployment.provider} not implemented yet`,
            );
        }
        resolve(deploymentUrl);
      } catch (error) {
        reject(error);
      }
    });

    // Add 5-minute timeout
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(
        () => {
          reject(new Error("Deployment timed out after 5 minutes"));
        },
        5 * 60 * 1000,
      );
    });

    deploymentUrl = await Promise.race([deploymentPromise, timeoutPromise]);

    logs.push("✅ Deployment successful!");
    logs.push(`🌐 Live at: ${deploymentUrl}`);
    deployment.status = "success";
    deployment.url = deploymentUrl;
    deployment.deployedAt = new Date().toISOString();
    deployment.buildLogs = [...logs];

    deployments.set(projectId, deployment);

    // Add to deployment history
    const history = deploymentHistory.get(projectId) || [];
    history.unshift({
      ...deployment,
      completedAt: new Date().toISOString(),
    });
    deploymentHistory.set(projectId, history.slice(0, 10));
  } catch (error) {
    console.error("Real deployment error:", error);
    logs.push(`❌ Deployment failed: ${error.message}`);
    deployment.status = "failed";
    deployment.buildLogs = [...logs];
    deployment.error = error.message;

    deployments.set(projectId, deployment);

    // Add to deployment history
    const history = deploymentHistory.get(projectId) || [];
    history.unshift({
      ...deployment,
      completedAt: new Date().toISOString(),
    });
    deploymentHistory.set(projectId, history.slice(0, 10));
  }
}

async function deployToAwureAIReal(
  projectId,
  deployment,
  files,
  providerConfig,
  projectName,
) {
  const logs = deployment.buildLogs;

  try {
    logs.push("🔥 Connecting to AwureAI hosting infrastructure...");
    deployment.buildLogs = [...logs];
    deployments.set(projectId, deployment);

    // Call our hosting API
    const response = await fetch(`${process.env.APP_URL}/api/hosting`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        projectName,
        files,
        deploymentId: deployment.id,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || "AwureAI hosting deployment failed");
    }

    const hostingResult = await response.json();

    logs.push("✅ Files uploaded to AwureAI infrastructure");
    logs.push(`🌐 Subdomain assigned: ${hostingResult.subdomain}`);
    logs.push("🔒 SSL certificate being provisioned...");
    deployment.buildLogs = [...logs];
    deployment.url = hostingResult.url;
    deployments.set(projectId, deployment);

    // Poll hosting status
    const pollHostingStatus = async () => {
      try {
        const statusResponse = await fetch(
          `${process.env.APP_URL}/api/hosting?deploymentId=${hostingResult.deploymentId}`,
        );
        const statusData = await statusResponse.json();

        if (statusData.deployment) {
          const hostingDeployment = statusData.deployment;

          // Update our deployment with hosting logs
          if (
            hostingDeployment.build_logs &&
            hostingDeployment.build_logs.length > 0
          ) {
            deployment.buildLogs = [...hostingDeployment.build_logs];
            deployments.set(projectId, deployment);
          }

          if (hostingDeployment.status === "success") {
            deployment.status = "success";
            deployment.deployedAt = new Date().toISOString();
            deployment.buildLogs.push(
              "✅ AwureAI hosting deployment completed!",
            );
            deployments.set(projectId, deployment);

            // Add to deployment history
            const history = deploymentHistory.get(projectId) || [];
            history.unshift({
              ...deployment,
              completedAt: new Date().toISOString(),
            });
            deploymentHistory.set(projectId, history.slice(0, 10));
            return;
          } else if (hostingDeployment.status === "failed") {
            deployment.status = "failed";
            deployment.buildLogs.push("❌ AwureAI hosting deployment failed");
            deployment.error =
              hostingDeployment.error_message || "Unknown hosting error";
            deployments.set(projectId, deployment);
            return;
          }
        }

        // Continue polling if still building
        setTimeout(pollHostingStatus, 2000);
      } catch (error) {
        console.error("Error polling hosting status:", error);
        deployment.status = "failed";
        deployment.error = "Failed to monitor deployment status";
        deployments.set(projectId, deployment);
      }
    };

    // Start polling
    setTimeout(pollHostingStatus, 1000);
  } catch (error) {
    console.error("AwureAI hosting deployment error:", error);
    logs.push(`❌ AwureAI hosting deployment failed: ${error.message}`);
    deployment.status = "failed";
    deployment.buildLogs = [...logs];
    deployment.error = error.message;

    deployments.set(projectId, deployment);

    // Add to deployment history
    const history = deploymentHistory.get(projectId) || [];
    history.unshift({
      ...deployment,
      completedAt: new Date().toISOString(),
    });
    deploymentHistory.set(projectId, history.slice(0, 10));
  }
}

async function deployToVercel(files, projectName, logs, deployment, projectId) {
  logs.push("🔧 Connecting to Vercel...");
  deployment.buildLogs = [...logs];
  deployments.set(projectId, deployment);

  // Check if we have VERCEL_TOKEN
  if (!process.env.VERCEL_TOKEN) {
    throw new Error(
      "VERCEL_TOKEN environment variable is not set. Please add your Vercel token to deploy.",
    );
  }

  const sanitizedName = projectName.toLowerCase().replace(/[^a-z0-9-]/g, "-");

  // Prepare files for Vercel with proper encoding
  const vercelFiles = [];
  files.forEach((file) => {
    if (file.content !== null && file.content !== undefined) {
      vercelFiles.push({
        file: file.name,
        data: file.content,
      });
    }
  });

  // Add package.json if it doesn't exist
  const hasPackageJson = files.some((f) => f.name === "package.json");
  if (!hasPackageJson) {
    vercelFiles.push({
      file: "package.json",
      data: JSON.stringify(
        {
          name: sanitizedName,
          version: "1.0.0",
          scripts: {
            build: "echo 'No build step needed'",
            start: "echo 'Static files ready'",
          },
          type: "module",
        },
        null,
        2,
      ),
    });
  }

  logs.push("🚀 Uploading to Vercel...");
  deployment.buildLogs = [...logs];
  deployments.set(projectId, deployment);

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 120000); // 2 minute timeout

  try {
    const deploymentPayload = {
      name: sanitizedName,
      files: vercelFiles,
      projectSettings: {
        framework: null,
      },
      target: "production",
    };

    console.log("Deploying to Vercel with payload:", {
      name: sanitizedName,
      fileCount: vercelFiles.length,
      files: vercelFiles.map((f) => ({ file: f.file, size: f.data.length })),
    });

    const response = await fetch("https://api.vercel.com/v13/deployments", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.VERCEL_TOKEN}`,
        "Content-Type": "application/json",
      },
      signal: controller.signal,
      body: JSON.stringify(deploymentPayload),
    });

    clearTimeout(timeoutId);

    const responseText = await response.text();
    console.log("Vercel response:", {
      status: response.status,
      body: responseText,
    });

    if (!response.ok) {
      let errorMessage = `Vercel deployment failed: ${response.status}`;
      try {
        const errorData = JSON.parse(responseText);
        if (errorData.error?.message) {
          errorMessage = errorData.error.message;
        }
      } catch (e) {
        errorMessage += ` - ${responseText}`;
      }
      throw new Error(errorMessage);
    }

    const result = JSON.parse(responseText);

    logs.push("⏳ Deployment is being processed by Vercel...");
    deployment.buildLogs = [...logs];
    deployments.set(projectId, deployment);

    // Wait a bit for Vercel to process
    await new Promise((resolve) => setTimeout(resolve, 2000));

    return `https://${result.url}`;
  } catch (error) {
    clearTimeout(timeoutId);
    if (error.name === "AbortError") {
      throw new Error("Vercel deployment timed out");
    }
    throw error;
  }
}

async function deployToNetlify(
  files,
  projectName,
  logs,
  deployment,
  projectId,
) {
  logs.push("🔧 Connecting to Netlify...");
  deployment.buildLogs = [...logs];
  deployments.set(projectId, deployment);

  // Check if we have NETLIFY_TOKEN
  if (!process.env.NETLIFY_TOKEN) {
    throw new Error(
      "NETLIFY_TOKEN environment variable is not set. Please add your Netlify token to deploy.",
    );
  }

  const sanitizedName = projectName.toLowerCase().replace(/[^a-z0-9-]/g, "-");

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 120000); // 2 minute timeout

  try {
    // First, create a new site on Netlify
    logs.push("🏗️ Creating new site on Netlify...");
    deployment.buildLogs = [...logs];
    deployments.set(projectId, deployment);

    const siteResponse = await fetch("https://api.netlify.com/api/v1/sites", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.NETLIFY_TOKEN}`,
        "Content-Type": "application/json",
      },
      signal: controller.signal,
      body: JSON.stringify({
        name: `${sanitizedName}-${Date.now().toString(36)}`,
      }),
    });

    if (!siteResponse.ok) {
      const errorData = await siteResponse.text();
      throw new Error(
        `Netlify site creation failed: ${siteResponse.status} ${errorData}`,
      );
    }

    const site = await siteResponse.json();
    console.log("Created Netlify site:", site);

    logs.push("📁 Preparing files for upload...");
    deployment.buildLogs = [...logs];
    deployments.set(projectId, deployment);

    // Prepare files for Netlify
    const netlifyFiles = {};
    files.forEach((file) => {
      if (file.content !== null && file.content !== undefined) {
        netlifyFiles[file.name] = file.content;
      }
    });

    // Ensure we have an index.html for static sites
    if (!netlifyFiles["index.html"]) {
      const jsFiles = Object.keys(netlifyFiles).filter((name) =>
        name.endsWith(".js"),
      );
      const cssFiles = Object.keys(netlifyFiles).filter((name) =>
        name.endsWith(".css"),
      );

      netlifyFiles["index.html"] = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${sanitizedName}</title>
  ${cssFiles.map((css) => `<link rel="stylesheet" href="./${css}">`).join("\n  ")}
</head>
<body>
  <div id="root">Loading...</div>
  ${jsFiles.map((js) => `<script src="./${js}"></script>`).join("\n  ")}
</body>
</html>`;
    }

    logs.push("🚀 Uploading files to Netlify...");
    deployment.buildLogs = [...logs];
    deployments.set(projectId, deployment);

    // Use Netlify's file-based deploy API
    const deployResponse = await fetch(
      `https://api.netlify.com/api/v1/sites/${site.id}/deploys`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${process.env.NETLIFY_TOKEN}`,
          "Content-Type": "application/json",
        },
        signal: controller.signal,
        body: JSON.stringify({
          files: netlifyFiles,
        }),
      },
    );

    clearTimeout(timeoutId);

    if (!deployResponse.ok) {
      const errorData = await deployResponse.text();
      console.error("Netlify deploy failed:", errorData);
      throw new Error(
        `Netlify deployment failed: ${deployResponse.status} ${errorData}`,
      );
    }

    const deployResult = await deployResponse.json();
    console.log("Netlify deploy result:", deployResult);

    logs.push("⏳ Deployment is being processed by Netlify...");
    deployment.buildLogs = [...logs];
    deployments.set(projectId, deployment);

    // Wait for deployment to be ready
    await new Promise((resolve) => setTimeout(resolve, 3000));

    return site.ssl_url || site.url;
  } catch (error) {
    clearTimeout(timeoutId);
    if (error.name === "AbortError") {
      throw new Error("Netlify deployment timed out");
    }
    throw error;
  }
}

async function deployToGitHubPages(
  files,
  projectName,
  logs,
  deployment,
  projectId,
) {
  logs.push("🔧 Connecting to GitHub...");
  deployment.buildLogs = [...logs];
  deployments.set(projectId, deployment);

  // Check if we have GITHUB_TOKEN
  if (!process.env.GITHUB_TOKEN) {
    throw new Error(
      "GITHUB_TOKEN environment variable is not set. Please add your GitHub token to deploy.",
    );
  }

  // This is a simplified implementation - GitHub Pages deployment would typically
  // involve creating a repository and pushing files
  throw new Error(
    "GitHub Pages deployment is not yet fully implemented. Please use Vercel or Netlify for now.",
  );
}

// Helper function to create a simple zip buffer (simplified version)
async function createZipBuffer(files) {
  // For a real implementation, you'd use a proper zip library
  // This is a placeholder - in production you'd need a real zip implementation
  return JSON.stringify(files);
}

// Helper functions
function generateDeploymentUrl(provider, projectName, deploymentId) {
  const sanitizedName = projectName.toLowerCase().replace(/[^a-z0-9-]/g, "-");

  switch (provider) {
    case "vercel":
      return `https://${sanitizedName}-${deploymentId}.vercel.app`;
    case "netlify":
      return `https://${sanitizedName}-${deploymentId}.netlify.app`;
    case "github-pages":
      return `https://username.github.io/${sanitizedName}`;
    case "awureai-hosting":
      return `https://demo-${sanitizedName}-${deploymentId}.awureai.app`;
    default:
      return `https://${sanitizedName}.example.com`;
  }
}

function simulateDeployment(projectId, deployment, files, providerConfig) {
  const logs = deployment.buildLogs;

  setTimeout(() => {
    logs.push("📦 Analyzing project files...");
    deployment.buildLogs = [...logs];
    deployments.set(projectId, deployment);
  }, 500);

  setTimeout(() => {
    logs.push(`🔧 Installing dependencies...`);
    logs.push(`📋 Found ${files.length} files to deploy`);
    deployment.buildLogs = [...logs];
    deployments.set(projectId, deployment);
  }, 1500);

  if (providerConfig.buildCommand) {
    setTimeout(() => {
      logs.push(`🏗️ Running build command: ${providerConfig.buildCommand}`);
      deployment.buildLogs = [...logs];
      deployments.set(projectId, deployment);
    }, 2500);
  }

  setTimeout(() => {
    logs.push("🚀 Deploying to global CDN...");
    deployment.buildLogs = [...logs];
    deployments.set(projectId, deployment);
  }, 3500);

  setTimeout(() => {
    logs.push("✅ Deployment successful!");
    logs.push(`🌐 Live at: ${deployment.url}`);
    deployment.status = "success";
    deployment.deployedAt = new Date().toISOString();
    deployment.buildLogs = [...logs];

    deployments.set(projectId, deployment);

    // Add to deployment history
    const history = deploymentHistory.get(projectId) || [];
    history.unshift({
      ...deployment,
      completedAt: new Date().toISOString(),
    });
    deploymentHistory.set(projectId, history.slice(0, 10));
  }, 4500);
}
