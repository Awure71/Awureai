// Real-time collaboration API for AwureAI IDE
let collaborationSessions = new Map();
let userPresence = new Map();
let chatMessages = new Map();

export async function GET(request) {
  try {
    const url = new URL(request.url);
    const projectId = url.searchParams.get("projectId");
    const action = url.searchParams.get("action");
    const userId = url.searchParams.get("userId");

    if (!projectId) {
      return Response.json({ error: "Project ID required" }, { status: 400 });
    }

    const session = collaborationSessions.get(projectId) || {
      id: projectId,
      users: [],
      activeUsers: [],
      chatEnabled: true,
      permissions: {
        owner: ["read", "write", "admin", "invite"],
        editor: ["read", "write"],
        viewer: ["read"],
      },
    };

    if (action === "presence") {
      const currentPresence = userPresence.get(projectId) || [];
      return Response.json({ users: currentPresence });
    }

    if (action === "chat") {
      const messages = chatMessages.get(projectId) || [];
      return Response.json({ messages: messages.slice(-50) });
    }

    if (action === "join" && userId) {
      const user = {
        id: userId,
        name: `Developer ${userId.slice(-4)}`,
        role: session.users.find((u) => u.id === userId)?.role || "viewer",
        joinedAt: new Date().toISOString(),
        cursor: null,
        selection: null,
      };

      if (!session.activeUsers.find((u) => u.id === userId)) {
        session.activeUsers.push(user);

        const currentPresence = userPresence.get(projectId) || [];
        userPresence.set(projectId, [
          ...currentPresence.filter((p) => p.id !== userId),
          user,
        ]);
      }

      collaborationSessions.set(projectId, session);
      return Response.json({
        session,
        user,
        message: `${user.name} joined the session`,
      });
    }

    return Response.json({ session });
  } catch (error) {
    return Response.json(
      { error: "Failed to get collaboration data" },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const { projectId, action, userId, data } = await request.json();

    if (!projectId || !userId) {
      return Response.json(
        { error: "Project ID and User ID required" },
        { status: 400 },
      );
    }

    let session = collaborationSessions.get(projectId) || {
      id: projectId,
      users: [],
      activeUsers: [],
      chatEnabled: true,
      permissions: {
        owner: ["read", "write", "admin", "invite"],
        editor: ["read", "write"],
        viewer: ["read"],
      },
    };

    switch (action) {
      case "create-session":
        session.owner = userId;
        session.users.push({
          id: userId,
          name: data.name || `Developer ${userId.slice(-4)}`,
          role: "owner",
          joinedAt: new Date().toISOString(),
        });
        collaborationSessions.set(projectId, session);
        return Response.json({
          session,
          message: "Collaboration session created",
        });

      case "invite-user":
        const { email, role = "editor" } = data;
        const invitation = {
          id: Math.random().toString(36).substring(7),
          email,
          role,
          invitedBy: userId,
          invitedAt: new Date().toISOString(),
          status: "pending",
        };
        session.invitations = session.invitations || [];
        session.invitations.push(invitation);
        collaborationSessions.set(projectId, session);
        return Response.json({
          invitation,
          message: `Invitation sent to ${email}`,
        });

      case "update-presence":
        const { cursor, selection, file } = data;
        const currentPresence = userPresence.get(projectId) || [];
        const userIndex = currentPresence.findIndex((u) => u.id === userId);

        if (userIndex !== -1) {
          currentPresence[userIndex] = {
            ...currentPresence[userIndex],
            cursor,
            selection,
            file,
            lastActive: new Date().toISOString(),
          };
        } else {
          currentPresence.push({
            id: userId,
            name: `Developer ${userId.slice(-4)}`,
            cursor,
            selection,
            file,
            lastActive: new Date().toISOString(),
          });
        }
        userPresence.set(projectId, currentPresence);
        return Response.json({
          presence: currentPresence,
          message: "Presence updated",
        });

      case "send-message":
        const { message, type = "text" } = data;
        const chatMessage = {
          id: Math.random().toString(36).substring(7),
          userId,
          userName: `Developer ${userId.slice(-4)}`,
          message,
          type,
          timestamp: new Date().toISOString(),
        };
        const messages = chatMessages.get(projectId) || [];
        messages.push(chatMessage);
        chatMessages.set(projectId, messages.slice(-100));
        return Response.json({ message: chatMessage, success: true });

      case "sync-changes":
        const { fileId, changes, version } = data;
        const changeEvent = {
          id: Math.random().toString(36).substring(7),
          userId,
          fileId,
          changes,
          version,
          timestamp: new Date().toISOString(),
          type: "file-change",
        };
        session.lastChange = changeEvent;
        collaborationSessions.set(projectId, session);
        return Response.json({
          changeEvent,
          conflicts: [],
          newVersion: version + 1,
        });

      case "leave-session":
        const userPresenceList = userPresence.get(projectId) || [];
        userPresence.set(
          projectId,
          userPresenceList.filter((p) => p.id !== userId),
        );
        session.activeUsers = session.activeUsers.filter(
          (u) => u.id !== userId,
        );
        collaborationSessions.set(projectId, session);
        return Response.json({ message: "Left collaboration session" });

      default:
        return Response.json({ error: "Invalid action" }, { status: 400 });
    }
  } catch (error) {
    return Response.json(
      { error: "Collaboration operation failed" },
      { status: 500 },
    );
  }
}
