export async function POST(request) {
  try {
    const { files, entrypoint, language = "javascript" } = await request.json();

    if (!files || !Array.isArray(files)) {
      return Response.json(
        { error: "Files array is required" },
        { status: 400 },
      );
    }

    // Find the entry file
    const entryFile = files.find((f) => f.name === entrypoint);
    if (!entryFile) {
      return Response.json(
        { error: `Entry file ${entrypoint} not found` },
        { status: 400 },
      );
    }

    let output = "";
    let hasError = false;

    try {
      // JavaScript/TypeScript execution
      if (
        entryFile.name.endsWith(".js") ||
        entryFile.name.endsWith(".jsx") ||
        entryFile.name.endsWith(".ts") ||
        entryFile.name.endsWith(".tsx")
      ) {
        output = await executeJavaScript(entryFile, files);
      }

      // Python execution simulation
      else if (entryFile.name.endsWith(".py")) {
        output = await executePython(entryFile, files);
      }

      // HTML execution (web app)
      else if (entryFile.name.endsWith(".html")) {
        output = await executeHTML(entryFile, files);
      }

      // CSS processing
      else if (entryFile.name.endsWith(".css")) {
        output =
          "CSS file processed successfully. Use with HTML to see styles.";
      }

      // JSON validation
      else if (entryFile.name.endsWith(".json")) {
        output = await validateJSON(entryFile);
      }

      // Markdown rendering
      else if (entryFile.name.endsWith(".md")) {
        output =
          "Markdown file ready. Content:\n" +
          entryFile.content.substring(0, 500) +
          "...";
      } else {
        output = `File type ${entryFile.name.split(".").pop()} execution not supported yet.\nSupported: .js, .jsx, .ts, .tsx, .py, .html, .css, .json, .md`;
        hasError = true;
      }
    } catch (error) {
      output = `Runtime Error: ${error.message}`;
      hasError = true;
    }

    return Response.json({
      output,
      status: hasError ? "error" : "success",
      executedFile: entrypoint,
      language: language,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Execution error:", error);
    return Response.json(
      {
        error: "Failed to execute code",
        details: error.message,
      },
      { status: 500 },
    );
  }
}

// Enhanced JavaScript execution with better error handling
async function executeJavaScript(entryFile, allFiles) {
  const logs = [];

  // Create execution context
  const originalConsole = console.log;
  console.log = (...args) => {
    logs.push(args.join(" "));
  };

  try {
    // Handle imports/requires (basic simulation)
    let code = entryFile.content;

    // Replace common imports with available functions
    code = code.replace(
      /import\s+.*?from\s+['"].*?['"];?\s*/g,
      "// Import statement (simulated)\n",
    );
    code = code.replace(
      /require\(['"].*?['"]\);?\s*/g,
      "// Require statement (simulated)\n",
    );

    // Add helper functions for app building
    const helperCode = `
      // AwureAI Helper functions for app building
      const createElement = (tag, props = {}, ...children) => {
        const element = { tag, props, children };
        console.log('Element created:', JSON.stringify(element, null, 2));
        return element;
      };
      
      const fetch = async (url, options = {}) => {
        console.log('Fetch call to:', url);
        return { 
          json: () => Promise.resolve({ message: 'Simulated API response' }),
          text: () => Promise.resolve('Simulated response'),
          ok: true,
          status: 200
        };
      };
    `;

    // Replace console.log calls to capture output
    const modifiedCode = code.replace(/console\.log\(/g, "captureLog(");

    // Create execution function
    const executeCode = new Function("captureLog", helperCode + modifiedCode);

    // Execute with our log capture function
    executeCode((...args) => {
      logs.push(args.join(" "));
    });

    return logs.join("\n") || "JavaScript executed successfully (no output)";
  } catch (error) {
    return `JavaScript Error: ${error.message}\n\nMake sure your code is valid JavaScript.`;
  } finally {
    console.log = originalConsole;
  }
}

// Python execution simulation
async function executePython(entryFile, allFiles) {
  const lines = entryFile.content.split("\n");
  const output = [];

  // Simple Python simulation
  try {
    for (const line of lines) {
      const trimmed = line.trim();

      if (trimmed.startsWith("print(") && trimmed.endsWith(")")) {
        // Extract print content
        const content = trimmed.slice(6, -1);
        // Simple string evaluation
        if (content.startsWith('"') && content.endsWith('"')) {
          output.push(content.slice(1, -1));
        } else if (content.startsWith("'") && content.endsWith("'")) {
          output.push(content.slice(1, -1));
        } else {
          output.push(content);
        }
      }
    }

    if (output.length === 0) {
      return "Python code executed successfully.\n\nNote: This is a simulation. For full Python support, a Python runtime would be required.\nCurrently supporting: print() statements, comments, basic syntax.";
    }

    return (
      output.join("\n") + "\n\n[Python simulation - limited functionality]"
    );
  } catch (error) {
    return `Python Error: ${error.message}`;
  }
}

// HTML execution (web app preview)
async function executeHTML(entryFile, allFiles) {
  try {
    // Find associated CSS and JS files
    const cssFiles = allFiles.filter((f) => f.name.endsWith(".css"));
    const jsFiles = allFiles.filter((f) => f.name.endsWith(".js"));

    let output = "HTML Web App Generated Successfully!\n\n";
    output += "🌐 HTML Structure: Ready\n";

    if (cssFiles.length > 0) {
      output += `🎨 CSS Styles: ${cssFiles.length} file(s) found\n`;
    }

    if (jsFiles.length > 0) {
      output += `⚡ JavaScript: ${jsFiles.length} file(s) found\n`;
    }

    output += "\n📱 Your web app is ready to preview!\n";
    output += "HTML content preview:\n";
    output += "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
    output +=
      entryFile.content.substring(0, 300) +
      (entryFile.content.length > 300 ? "..." : "");
    output += "\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━";

    return output;
  } catch (error) {
    return `HTML Processing Error: ${error.message}`;
  }
}

// JSON validation
async function validateJSON(entryFile) {
  try {
    JSON.parse(entryFile.content);
    return (
      "✅ JSON is valid!\n\nFormatted JSON:\n" +
      JSON.stringify(JSON.parse(entryFile.content), null, 2)
    );
  } catch (error) {
    return `❌ JSON Validation Error: ${error.message}`;
  }
}
