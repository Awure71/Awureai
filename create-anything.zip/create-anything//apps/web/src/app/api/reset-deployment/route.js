// Reset stuck deployments
let deployments = new Map();
let deploymentHistory = new Map();

export async function POST(request) {
  try {
    const { projectId } = await request.json();

    if (!projectId) {
      return Response.json({ error: "Project ID required" }, { status: 400 });
    }

    const deployment = deployments.get(projectId);

    if (deployment) {
      // Check if deployment is stuck (building for more than 10 minutes)
      const createdAt = new Date(deployment.createdAt);
      const now = new Date();
      const diffInMinutes = (now - createdAt) / (1000 * 60);

      if (deployment.status === "building" && diffInMinutes > 10) {
        // Reset stuck deployment
        deployment.status = "failed";
        deployment.buildLogs.push("❌ Deployment was reset due to timeout");
        deployment.error = "Deployment timed out and was reset";
        deployment.completedAt = new Date().toISOString();

        deployments.set(projectId, deployment);

        // Add to history
        const history = deploymentHistory.get(projectId) || [];
        history.unshift({
          ...deployment,
          resetAt: new Date().toISOString(),
        });
        deploymentHistory.set(projectId, history.slice(0, 10));

        return Response.json({
          message: "Stuck deployment has been reset",
          deployment: deployment,
        });
      } else {
        return Response.json({
          message: "Deployment is not stuck",
          deployment: deployment,
        });
      }
    } else {
      return Response.json(
        { error: "No deployment found for this project" },
        { status: 404 },
      );
    }
  } catch (error) {
    console.error("Error resetting deployment:", error);
    return Response.json(
      { error: "Failed to reset deployment" },
      { status: 500 },
    );
  }
}

export async function GET(request) {
  try {
    const url = new URL(request.url);
    const projectId = url.searchParams.get("projectId");

    if (!projectId) {
      return Response.json({ error: "Project ID required" }, { status: 400 });
    }

    const deployment = deployments.get(projectId);

    if (deployment) {
      const createdAt = new Date(deployment.createdAt);
      const now = new Date();
      const diffInMinutes = (now - createdAt) / (1000 * 60);
      const isStuck = deployment.status === "building" && diffInMinutes > 10;

      return Response.json({
        deployment: deployment,
        isStuck: isStuck,
        minutesRunning: Math.floor(diffInMinutes),
      });
    } else {
      return Response.json({
        deployment: null,
        isStuck: false,
        minutesRunning: 0,
      });
    }
  } catch (error) {
    console.error("Error checking deployment:", error);
    return Response.json(
      { error: "Failed to check deployment status" },
      { status: 500 },
    );
  }
}
