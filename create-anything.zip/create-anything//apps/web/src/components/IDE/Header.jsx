import { useState } from "react";
import {
  Play,
  Square,
  Share,
  Settings,
  User,
  Save,
  Globe,
  Package,
  GitBranch,
  Monitor,
  Rocket,
  Users,
} from "lucide-react";
import { DeployModal } from "./DeployModal";

export function Header({ onRun, isRunning, projectName, isSaving }) {
  const [isDeployModalOpen, setIsDeployModalOpen] = useState(false);

  return (
    <>
      <header className="h-12 bg-white border-b border-gray-200 flex items-center justify-between px-4">
        {/* Left side - AwureAI Logo and project name */}
        <div className="flex items-center space-x-4">
          <div className="text-lg font-bold text-gray-900 flex items-center space-x-2">
            <div className="w-6 h-6 bg-gradient-to-r from-blue-500 to-purple-600 rounded-md flex items-center justify-center text-xs font-bold text-white">
              A
            </div>
            <span>AwureAI</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="text-sm text-gray-600">{projectName}</div>
            {isSaving && (
              <div className="flex items-center space-x-1 text-xs text-blue-600">
                <Save size={12} className="animate-pulse" />
                <span>Saving...</span>
              </div>
            )}
          </div>
        </div>

        {/* Center - Enhanced controls */}
        <div className="flex items-center space-x-2">
          <button
            onClick={onRun}
            disabled={isRunning}
            className={`flex items-center space-x-2 px-4 py-2 rounded-md font-medium transition-colors ${
              isRunning
                ? "bg-gray-200 text-gray-500 cursor-not-allowed"
                : "bg-green-600 hover:bg-green-700 text-white"
            }`}
          >
            {isRunning ? (
              <>
                <Square size={16} />
                <span>Running...</span>
              </>
            ) : (
              <>
                <Play size={16} />
                <span>Run</span>
              </>
            )}
          </button>

          <button className="flex items-center space-x-2 px-3 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-md transition-colors">
            <Monitor size={16} />
            <span>Preview</span>
          </button>

          <button className="flex items-center space-x-2 px-3 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-md transition-colors">
            <Package size={16} />
            <span>Packages</span>
          </button>

          {/* Git Controls */}
          <div className="flex items-center space-x-1 border-l border-gray-200 pl-3">
            <button className="flex items-center space-x-1 px-2 py-1 text-gray-500 hover:text-gray-900 hover:bg-gray-100 rounded-md transition-colors">
              <GitBranch size={16} />
              <span className="text-sm">main</span>
            </button>
          </div>

          {/* Deployment */}
          <button
            onClick={() => setIsDeployModalOpen(true)}
            className="flex items-center space-x-2 px-3 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-md transition-colors"
          >
            <Rocket size={16} />
            <span>Deploy</span>
          </button>

          {/* Collaboration */}
          <button className="flex items-center space-x-2 px-3 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-md transition-colors">
            <Users size={16} />
            <span>Collaborate</span>
          </button>
        </div>

        {/* Right side - Actions */}
        <div className="flex items-center space-x-2">
          <button className="p-2 text-gray-500 hover:text-gray-900 hover:bg-gray-100 rounded-md transition-colors">
            <Globe size={18} />
          </button>
          <button className="p-2 text-gray-500 hover:text-gray-900 hover:bg-gray-100 rounded-md transition-colors">
            <Share size={18} />
          </button>
          <button className="p-2 text-gray-500 hover:text-gray-900 hover:bg-gray-100 rounded-md transition-colors">
            <Settings size={18} />
          </button>
          <button className="p-2 text-gray-500 hover:text-gray-900 hover:bg-gray-100 rounded-md transition-colors">
            <User size={18} />
          </button>
        </div>
      </header>

      {/* Deploy Modal */}
      <DeployModal
        isOpen={isDeployModalOpen}
        onClose={() => setIsDeployModalOpen(false)}
        projectName={projectName}
      />
    </>
  );
}
