import { useState, useEffect } from "react";
import { GitBranch, GitCommit, Plus, Check, Clock, User } from "lucide-react";

export function GitPanel({ projectId = "default", isVisible = false }) {
  const [gitStatus, setGitStatus] = useState(null);
  const [commits, setCommits] = useState([]);
  const [branches, setBranches] = useState([]);
  const [commitMessage, setCommitMessage] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isVisible) {
      fetchGitStatus();
      fetchCommits();
      fetchBranches();
    }
  }, [isVisible, projectId]);

  const fetchGitStatus = async () => {
    try {
      const response = await fetch(
        `/api/git?projectId=${projectId}&action=status`,
      );
      if (response.ok) {
        const status = await response.json();
        setGitStatus(status);
      }
    } catch (error) {
      console.error("Failed to fetch git status:", error);
    }
  };

  const fetchCommits = async () => {
    try {
      const response = await fetch(
        `/api/git?projectId=${projectId}&action=log`,
      );
      if (response.ok) {
        const data = await response.json();
        setCommits(data.commits);
      }
    } catch (error) {
      console.error("Failed to fetch commits:", error);
    }
  };

  const fetchBranches = async () => {
    try {
      const response = await fetch(
        `/api/git?projectId=${projectId}&action=branches`,
      );
      if (response.ok) {
        const data = await response.json();
        setBranches(data.branches);
      }
    } catch (error) {
      console.error("Failed to fetch branches:", error);
    }
  };

  const handleGitCommand = async (command, args = []) => {
    setLoading(true);
    try {
      const response = await fetch("/api/git", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          projectId,
          command,
          args,
          message: commitMessage,
        }),
      });

      if (response.ok) {
        const result = await response.json();
        fetchGitStatus();
        fetchCommits();
        fetchBranches();

        if (command === "commit") {
          setCommitMessage("");
        }

        return result;
      } else {
        const error = await response.json();
        throw new Error(error.error);
      }
    } catch (error) {
      console.error("Git command failed:", error);
      alert(`Git error: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const formatTimeAgo = (dateString) => {
    const now = new Date();
    const date = new Date(dateString);
    const diff = now - date;

    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return "Just now";
  };

  if (!isVisible) return null;

  return (
    <div className="w-80 bg-[#1e1e1e] border-l border-[#3e3e42] flex flex-col">
      {/* Git Panel Header */}
      <div className="h-12 bg-[#2d2d30] border-b border-[#3e3e42] flex items-center px-4">
        <GitBranch size={16} className="text-blue-400 mr-2" />
        <span className="text-white font-medium">Git</span>
        <div className="ml-auto flex items-center space-x-2">
          {gitStatus?.branch && (
            <span className="text-xs bg-blue-500 text-white px-2 py-1 rounded">
              {gitStatus.branch}
            </span>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-hidden flex flex-col">
        {/* Repository Status */}
        <div className="p-4 border-b border-[#3e3e42]">
          <h3 className="text-sm font-medium text-white mb-3">
            Repository Status
          </h3>

          {!gitStatus ? (
            <div className="text-center py-4">
              <button
                onClick={() => handleGitCommand("init")}
                disabled={loading}
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
              >
                Initialize Repository
              </button>
            </div>
          ) : (
            <div className="space-y-2">
              {/* Staged files */}
              {gitStatus.staged?.length > 0 && (
                <div>
                  <div className="text-xs text-green-400 mb-1">
                    Staged ({gitStatus.staged.length})
                  </div>
                  {gitStatus.staged.map((file, index) => (
                    <div
                      key={index}
                      className="flex items-center text-xs text-green-300"
                    >
                      <Check size={12} className="mr-2" />
                      {file.name}
                    </div>
                  ))}
                </div>
              )}

              {/* Modified files */}
              {gitStatus.modified?.length > 0 && (
                <div>
                  <div className="text-xs text-yellow-400 mb-1">
                    Modified ({gitStatus.modified.length})
                  </div>
                  {gitStatus.modified.map((file, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between text-xs"
                    >
                      <span className="text-yellow-300">{file.name}</span>
                      <button
                        onClick={() => handleGitCommand("add", [file.name])}
                        className="text-blue-400 hover:text-blue-300"
                      >
                        <Plus size={12} />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {/* Untracked files */}
              {gitStatus.untracked?.length > 0 && (
                <div>
                  <div className="text-xs text-gray-400 mb-1">
                    Untracked ({gitStatus.untracked.length})
                  </div>
                  {gitStatus.untracked.map((file, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between text-xs"
                    >
                      <span className="text-gray-300">{file.name}</span>
                      <button
                        onClick={() => handleGitCommand("add", [file.name])}
                        className="text-blue-400 hover:text-blue-300"
                      >
                        <Plus size={12} />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {/* Quick actions */}
              <div className="flex space-x-2 mt-3">
                <button
                  onClick={() => handleGitCommand("add", ["."])}
                  disabled={loading}
                  className="px-2 py-1 text-xs bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
                >
                  Stage All
                </button>
                <button
                  onClick={fetchGitStatus}
                  disabled={loading}
                  className="px-2 py-1 text-xs bg-gray-600 text-white rounded hover:bg-gray-700 disabled:opacity-50"
                >
                  Refresh
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Commit Section */}
        {gitStatus && (
          <div className="p-4 border-b border-[#3e3e42]">
            <h3 className="text-sm font-medium text-white mb-3">
              Commit Changes
            </h3>
            <div className="space-y-2">
              <textarea
                value={commitMessage}
                onChange={(e) => setCommitMessage(e.target.value)}
                placeholder="Enter commit message..."
                className="w-full h-16 px-3 py-2 bg-[#2d2d30] border border-[#3e3e42] rounded text-sm text-white placeholder-gray-400 resize-none focus:outline-none focus:border-blue-500"
              />
              <button
                onClick={() => handleGitCommand("commit")}
                disabled={
                  loading || !commitMessage.trim() || !gitStatus.staged?.length
                }
                className="w-full px-3 py-2 bg-green-600 text-white rounded hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed text-sm"
              >
                {loading
                  ? "Committing..."
                  : `Commit (${gitStatus.staged?.length || 0})`}
              </button>
            </div>
          </div>
        )}

        {/* Commit History */}
        <div className="flex-1 overflow-auto">
          <div className="p-4">
            <h3 className="text-sm font-medium text-white mb-3 flex items-center">
              <GitCommit size={14} className="mr-2" />
              Recent Commits
            </h3>

            {commits.length === 0 ? (
              <div className="text-xs text-gray-400 text-center py-4">
                No commits yet
              </div>
            ) : (
              <div className="space-y-3">
                {commits.map((commit, index) => (
                  <div
                    key={commit.id}
                    className="border border-[#3e3e42] rounded p-3 bg-[#2d2d30]"
                  >
                    <div className="flex items-start justify-between mb-1">
                      <div className="text-xs text-white font-medium truncate flex-1">
                        {commit.message}
                      </div>
                      <span className="text-xs text-gray-400 ml-2">
                        {formatTimeAgo(commit.date)}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2 text-xs text-gray-400">
                      <User size={10} />
                      <span>{commit.author}</span>
                      <span>•</span>
                      <span className="font-mono">{commit.id}</span>
                    </div>
                    {commit.files && (
                      <div className="mt-2 text-xs text-gray-500">
                        {commit.files.length} file
                        {commit.files.length !== 1 ? "s" : ""} changed
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
