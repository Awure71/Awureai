import { useState, useEffect } from "react";
import {
  Rocket,
  X,
  CheckCircle,
  AlertCircle,
  ExternalLink,
  Copy,
  Loader2,
} from "lucide-react";
import { DeploymentSetup } from "./DeploymentSetup";

export function DeployModal({ isOpen, onClose, projectName }) {
  const [selectedProvider, setSelectedProvider] = useState("awureai-hosting"); // Default to demo provider
  const [deployment, setDeployment] = useState(null);
  const [isDeploying, setIsDeploying] = useState(false);
  const [deploymentLogs, setDeploymentLogs] = useState([]);
  const [providers, setProviders] = useState({});
  const [showSetup, setShowSetup] = useState(false);
  const [missingEnvVars, setMissingEnvVars] = useState([]);

  useEffect(() => {
    if (isOpen) {
      fetchProviders();
      // Reset states when opening
      setDeployment(null);
      setIsDeploying(false);
      setShowSetup(false);
      setMissingEnvVars([]);
      // Reset to demo provider to ensure we have a valid provider
      setSelectedProvider("awureai-hosting");
    }
  }, [isOpen]);

  const fetchProviders = async () => {
    try {
      const response = await fetch("/api/deploy?action=providers");
      const data = await response.json();
      setProviders(data.providers || {});
    } catch (error) {
      console.error("Failed to fetch providers:", error);
    }
  };

  const startDeployment = async () => {
    setIsDeploying(true);
    setDeploymentLogs(["🚀 Starting deployment..."]);

    try {
      // Get project files with actual content
      const projectFiles = [
        {
          name: "index.html",
          content: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${projectName || "AwureAI Project"}</title>
    <style>
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            margin: 0;
            text-align: center;
        }
        .container { max-width: 600px; padding: 40px; }
        h1 { font-size: 3rem; margin-bottom: 20px; }
        p { font-size: 1.2rem; opacity: 0.9; }
        .deployed-badge { 
            background: rgba(255,255,255,0.2); 
            padding: 8px 16px; 
            border-radius: 20px; 
            display: inline-block; 
            margin-top: 20px;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 ${projectName || "AwureAI Project"}</h1>
        <p>Your project has been successfully deployed!</p>
        <div class="deployed-badge">
            ✅ Deployed with AwureAI • ${new Date().toLocaleString()}
        </div>
        <div style="margin-top: 30px; font-size: 0.9rem; opacity: 0.8;">
            <p>🌐 Deployment ID: ${Date.now()}</p>
            <p>📦 Files: index.html, style.css, script.js</p>
        </div>
    </div>
    <script src="./script.js"></script>
</body>
</html>`,
        },
        {
          name: "style.css",
          content: `/* Additional styles for ${projectName || "AwureAI Project"} */
body { 
  margin: 0; 
  font-family: system-ui, -apple-system, sans-serif; 
}`,
        },
        {
          name: "script.js",
          content: `console.log('${projectName || "AwureAI Project"} deployed successfully!');
console.log('Deployment timestamp:', '${new Date().toISOString()}');
document.addEventListener('DOMContentLoaded', function() {
  console.log('Page loaded successfully at:', new Date().toISOString());
  
  // Add some interactive demo functionality
  document.body.addEventListener('click', function() {
    console.log('Demo deployment working! Click detected at:', new Date().toISOString());
  });
});`,
        },
      ];

      setDeploymentLogs((prev) => [
        ...prev,
        `📁 Prepared ${projectFiles.length} files for deployment`,
        `🎯 Target provider: ${providers[selectedProvider]?.name || selectedProvider}`,
      ]);

      const response = await fetch("/api/deploy", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          projectId: "current-project",
          provider: selectedProvider,
          files: projectFiles,
          projectName: projectName || "AwureAI Project",
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        if (data.missingEnvVars) {
          // Handle missing environment variables
          setMissingEnvVars(data.missingEnvVars);
          setShowSetup(true);
          setIsDeploying(false);
          return;
        }
        throw new Error(data.error || "Deployment failed");
      }

      setDeploymentLogs((prev) => [
        ...prev,
        `✅ Deployment request accepted`,
        `🆔 Deployment ID: ${data.deployment?.id}`,
        `🌐 Target URL: ${data.deployment?.url}`,
      ]);

      if (data.deployment) {
        setDeployment(data.deployment);
        pollDeploymentStatus();
      }
    } catch (error) {
      console.error("Deployment failed:", error);
      setDeploymentLogs((prev) => [
        ...prev,
        "❌ Deployment failed: " + error.message,
      ]);
      setIsDeploying(false);
    }
  };

  const handleSetupComplete = (envVarName, token) => {
    setShowSetup(false);
    setDeploymentLogs([
      `✅ ${envVarName} configured successfully!`,
      "🚀 Starting deployment...",
    ]);

    // In a real app, you'd save the token as an environment variable
    // For demo purposes, we'll show instructions and then try demo deployment
    alert(
      `✅ Setup Complete!\n\nEnvironment variable ${envVarName} would be set securely in your deployment environment.\n\n🚀 For demo purposes, we'll use the AwureAI demo deployment instead.`,
    );

    // Switch to demo provider for now
    setSelectedProvider("awureai-hosting");
    startDeployment();
  };

  const pollDeploymentStatus = () => {
    const interval = setInterval(async () => {
      try {
        const response = await fetch("/api/deploy?projectId=current-project");
        const data = await response.json();

        if (data.deployment) {
          setDeployment(data.deployment);
          setDeploymentLogs(data.deployment.buildLogs || []);

          if (
            data.deployment.status === "success" ||
            data.deployment.status === "failed"
          ) {
            setIsDeploying(false);
            clearInterval(interval);
          }
        }
      } catch (error) {
        console.error("Failed to poll deployment:", error);
        clearInterval(interval);
        setIsDeploying(false);
      }
    }, 1000);
  };

  const copyUrl = () => {
    if (deployment?.url) {
      navigator.clipboard.writeText(deployment.url);
    }
  };

  const visitSite = () => {
    if (deployment?.url) {
      window.open(deployment.url, "_blank");
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl mx-4 max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <Rocket className="text-blue-600" size={24} />
            <h2 className="text-xl font-semibold text-gray-900">
              {showSetup ? "Setup Deployment" : "Deploy Project"}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        {showSetup ? (
          <DeploymentSetup
            provider={selectedProvider}
            onComplete={handleSetupComplete}
            onCancel={() => setShowSetup(false)}
          />
        ) : (
          <div className="p-6">
            {!deployment && !isDeploying && (
              <>
                {/* Provider Selection */}
                <div className="mb-6">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">
                    Choose Deployment Provider
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {Object.entries(providers).map(([key, provider]) => (
                      <div
                        key={key}
                        className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                          selectedProvider === key
                            ? "border-blue-500 bg-blue-50"
                            : "border-gray-200 hover:border-gray-300"
                        }`}
                        onClick={() => setSelectedProvider(key)}
                      >
                        <div className="flex items-center space-x-3">
                          <span className="text-2xl">{provider.icon}</span>
                          <div>
                            <h4 className="font-medium text-gray-900">
                              {provider.name}
                            </h4>
                            <p className="text-sm text-gray-600">
                              {provider.description}
                            </p>
                            {provider.requiresAuth && (
                              <p className="text-xs text-orange-600 mt-1">
                                Requires setup
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Deploy Button */}
                <button
                  onClick={startDeployment}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-4 rounded-lg transition-colors flex items-center justify-center space-x-2"
                >
                  <Rocket size={18} />
                  <span>Deploy Now</span>
                </button>
              </>
            )}

            {/* Deployment Progress */}
            {(deployment || isDeploying) && (
              <div className="space-y-4">
                {/* Status */}
                <div className="flex items-center space-x-3">
                  {deployment?.status === "success" && (
                    <>
                      <CheckCircle className="text-green-600" size={24} />
                      <span className="text-green-600 font-medium">
                        Deployment Successful!
                      </span>
                    </>
                  )}
                  {deployment?.status === "building" && (
                    <>
                      <Loader2
                        className="text-blue-600 animate-spin"
                        size={24}
                      />
                      <span className="text-blue-600 font-medium">
                        Deploying...
                      </span>
                    </>
                  )}
                  {deployment?.status === "failed" && (
                    <>
                      <AlertCircle className="text-red-600" size={24} />
                      <span className="text-red-600 font-medium">
                        Deployment Failed
                      </span>
                    </>
                  )}
                </div>

                {/* URL Display */}
                {deployment?.url && (
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Live URL
                    </label>
                    <div className="flex items-center space-x-2">
                      <input
                        type="text"
                        value={deployment.url}
                        readOnly
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-md bg-white text-sm"
                      />
                      <button
                        onClick={copyUrl}
                        className="p-2 text-gray-500 hover:text-gray-700 transition-colors"
                        title="Copy URL"
                      >
                        <Copy size={18} />
                      </button>
                      <button
                        onClick={visitSite}
                        className="flex items-center space-x-1 px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors text-sm"
                      >
                        <ExternalLink size={16} />
                        <span>Visit</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* Build Logs */}
                <div className="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm max-h-64 overflow-y-auto">
                  {deploymentLogs.map((log, index) => (
                    <div key={index} className="mb-1">
                      {log}
                    </div>
                  ))}
                  {isDeploying && (
                    <div className="flex items-center space-x-2 text-blue-400">
                      <Loader2 size={14} className="animate-spin" />
                      <span>Building...</span>
                    </div>
                  )}
                </div>

                {/* Success Actions */}
                {deployment?.status === "success" && (
                  <div className="flex space-x-3">
                    <button
                      onClick={visitSite}
                      className="flex-1 bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded-lg transition-colors flex items-center justify-center space-x-2"
                    >
                      <ExternalLink size={18} />
                      <span>View Live Site</span>
                    </button>
                    <button
                      onClick={onClose}
                      className="flex-1 bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-4 rounded-lg transition-colors"
                    >
                      Close
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
