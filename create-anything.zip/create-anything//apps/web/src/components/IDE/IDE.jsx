import { useState, useEffect } from "react";
import { Header } from "./Header";
import { FileExplorer } from "./FileExplorer";
import { CodeEditor } from "./CodeEditor";
import { Terminal } from "./Terminal";
import { StatusBar } from "./StatusBar";

export function IDE() {
  const [project, setProject] = useState(null);
  const [files, setFiles] = useState([]);
  const [activeFile, setActiveFile] = useState(null);
  const [terminalOutput, setTerminalOutput] = useState([
    {
      type: "info",
      content: 'Welcome to the terminal! Type "run" to execute your code.',
    },
  ]);
  const [isRunning, setIsRunning] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Load project on mount
  useEffect(() => {
    loadProject();
  }, []);

  // Auto-save when files change
  useEffect(() => {
    if (project && files.length > 0) {
      const timeoutId = setTimeout(() => {
        saveProject();
      }, 2000); // Auto-save after 2 seconds of inactivity

      return () => clearTimeout(timeoutId);
    }
  }, [files, project]);

  const loadProject = async () => {
    try {
      const response = await fetch("/api/projects?id=1");
      if (!response.ok) {
        throw new Error("Failed to load project");
      }
      const projectData = await response.json();
      setProject(projectData);
      setFiles(projectData.files || []);
      setActiveFile(projectData.files?.[0] || null);
    } catch (error) {
      console.error("Error loading project:", error);
      // Fallback to default files
      const defaultFiles = [
        {
          id: "1",
          name: "index.js",
          type: "file",
          content: `// Welcome to your Replit-like IDE!
console.log("Hello, World!");

function greet(name) {
  return \`Hello, \${name}!\`;
}

console.log(greet("Developer"));`,
          language: "javascript",
        },
      ];
      setFiles(defaultFiles);
      setActiveFile(defaultFiles[0]);
    }
  };

  const saveProject = async () => {
    if (!project) return;

    setIsSaving(true);
    try {
      const response = await fetch("/api/projects", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: project.id,
          files: files.map((f) => ({
            id: f.id,
            name: f.name,
            type: f.type,
            content: f.content,
            language: f.language,
          })),
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to save project");
      }
    } catch (error) {
      console.error("Error saving project:", error);
      setTerminalOutput((prev) => [
        ...prev,
        { type: "error", content: `Auto-save failed: ${error.message}` },
      ]);
    } finally {
      setIsSaving(false);
    }
  };

  const updateFileContent = (fileId, newContent) => {
    setFiles((prevFiles) =>
      prevFiles.map((file) =>
        file.id === fileId ? { ...file, content: newContent } : file,
      ),
    );

    if (activeFile?.id === fileId) {
      setActiveFile((prev) => ({ ...prev, content: newContent }));
    }
  };

  const createNewFile = (name, type = "file") => {
    const newFile = {
      id: Date.now().toString(),
      name,
      type,
      content: type === "file" ? "" : null,
      language: getLanguageFromExtension(name),
    };
    setFiles((prev) => [...prev, newFile]);
    if (type === "file") {
      setActiveFile(newFile);
    }
  };

  const deleteFile = (fileId) => {
    setFiles((prev) => prev.filter((file) => file.id !== fileId));
    if (activeFile?.id === fileId) {
      const remainingFiles = files.filter((file) => file.id !== fileId);
      setActiveFile(remainingFiles[0] || null);
    }
  };

  const getLanguageFromExtension = (filename) => {
    const ext = filename.split(".").pop().toLowerCase();
    const languageMap = {
      js: "javascript",
      jsx: "javascript",
      ts: "typescript",
      tsx: "typescript",
      py: "python",
      css: "css",
      html: "html",
      json: "json",
      md: "markdown",
    };
    return languageMap[ext] || "text";
  };

  const runCode = async () => {
    setIsRunning(true);
    setTerminalOutput((prev) => [
      ...prev,
      { type: "command", content: "$ npm start" },
      { type: "info", content: "Running your code..." },
    ]);

    try {
      const response = await fetch("/api/execute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          files: files.map((f) => ({ name: f.name, content: f.content })),
          entrypoint: "index.js",
        }),
      });

      if (!response.ok) {
        throw new Error(`Execution failed: ${response.statusText}`);
      }

      const result = await response.json();

      setTerminalOutput((prev) => [
        ...prev,
        {
          type: "success",
          content: result.output || "Code executed successfully!",
        },
      ]);
    } catch (error) {
      setTerminalOutput((prev) => [
        ...prev,
        { type: "error", content: `Error: ${error.message}` },
      ]);
    } finally {
      setIsRunning(false);
    }
  };

  const clearTerminal = () => {
    setTerminalOutput([
      {
        type: "info",
        content: 'Terminal cleared. Type "run" to execute your code.',
      },
    ]);
  };

  return (
    <div className="h-screen flex flex-col bg-white text-gray-900">
      <Header
        onRun={runCode}
        isRunning={isRunning}
        projectName={project?.name || "my-awesome-project"}
        isSaving={isSaving}
      />

      <div className="flex-1 flex overflow-hidden">
        {/* File Explorer */}
        <div className="w-64 bg-gray-50 border-r border-gray-200 flex-shrink-0">
          <FileExplorer
            files={files}
            activeFile={activeFile}
            onFileSelect={setActiveFile}
            onCreateFile={createNewFile}
            onDeleteFile={deleteFile}
          />
        </div>

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col">
          {/* Code Editor */}
          <div className="flex-1">
            <CodeEditor file={activeFile} onContentChange={updateFileContent} />
          </div>

          {/* Terminal */}
          <div className="h-64 border-t border-gray-200">
            <Terminal
              output={terminalOutput}
              onCommand={runCode}
              onClear={clearTerminal}
              isRunning={isRunning}
            />
          </div>
        </div>
      </div>

      <StatusBar activeFile={activeFile} isSaving={isSaving} />
    </div>
  );
}
