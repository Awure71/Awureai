import { useState, useRef, useEffect } from "react";
import { Terminal as TerminalIcon, X, Minus, Square } from "lucide-react";

export function Terminal({ output, onCommand, onClear, isRunning }) {
  const [input, setInput] = useState("");
  const [isMinimized, setIsMinimized] = useState(false);
  const terminalRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [output]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const command = input.trim();

    if (command === "run" && onCommand) {
      onCommand();
    } else if (command === "clear" && onClear) {
      onClear();
    } else if (command === "help") {
      // Add help command output to terminal
      console.log("Available commands: run, clear, help");
    } else if (command) {
      // Handle other commands here
      console.log("Unknown command:", command);
    }
    setInput("");
  };

  const getOutputColor = (type) => {
    switch (type) {
      case "error":
        return "text-red-400";
      case "success":
        return "text-green-400";
      case "info":
        return "text-blue-400";
      case "command":
        return "text-yellow-400";
      default:
        return "text-gray-300";
    }
  };

  if (isMinimized) {
    return (
      <div className="h-8 bg-[#1e1e1e] border-t border-[#3e3e42] flex items-center justify-between px-4">
        <div className="flex items-center space-x-2">
          <TerminalIcon size={14} className="text-gray-400" />
          <span className="text-sm text-gray-400">Terminal</span>
        </div>
        <button
          onClick={() => setIsMinimized(false)}
          className="text-gray-400 hover:text-white"
        >
          <Square size={14} />
        </button>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-[#1e1e1e]">
      {/* Terminal header */}
      <div className="h-8 bg-[#2d2d30] border-b border-[#3e3e42] flex items-center justify-between px-4">
        <div className="flex items-center space-x-2">
          <TerminalIcon size={14} className="text-gray-400" />
          <span className="text-sm text-gray-400">Terminal</span>
        </div>
        <div className="flex items-center space-x-1">
          <button
            onClick={() => setIsMinimized(true)}
            className="p-1 text-gray-400 hover:text-white hover:bg-[#3e3e42] rounded"
          >
            <Minus size={12} />
          </button>
        </div>
      </div>

      {/* Terminal output */}
      <div
        ref={terminalRef}
        className="flex-1 overflow-y-auto p-4 font-mono text-sm"
      >
        {output.map((line, index) => (
          <div key={index} className={`mb-1 ${getOutputColor(line.type)}`}>
            {line.type === "command" && (
              <span className="text-gray-500">$ </span>
            )}
            {line.content}
          </div>
        ))}

        {isRunning && (
          <div className="text-yellow-400 mb-1">
            <span className="animate-pulse">●</span> Executing...
          </div>
        )}
      </div>

      {/* Terminal input */}
      <div className="border-t border-[#3e3e42] p-4">
        <form onSubmit={handleSubmit} className="flex items-center space-x-2">
          <span className="text-gray-500 font-mono text-sm">$</span>
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type 'run' to execute code, 'clear' to clear output, 'help' for commands..."
            className="flex-1 bg-transparent text-gray-300 font-mono text-sm focus:outline-none"
            disabled={isRunning}
          />
        </form>

        <div className="mt-2 text-xs text-gray-500">
          Available commands: <span className="text-blue-400">run</span>,{" "}
          <span className="text-blue-400">clear</span>,{" "}
          <span className="text-blue-400">help</span>
        </div>
      </div>
    </div>
  );
}
