import { useState, useEffect, useRef } from "react";
import { Search, X } from "lucide-react";
import classNames from "classnames";

export function CodeEditor({ file, onContentChange }) {
  const textareaRef = useRef(null);
  const [content, setContent] = useState(file?.content || "");
  const [cursorPosition, setCursorPosition] = useState({ line: 1, column: 1 });
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const searchInputRef = useRef(null);

  useEffect(() => {
    if (file) {
      setContent(file.content || "");
    }
  }, [file]);

  useEffect(() => {
    if (showSearch && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [showSearch]);

  const handleContentChange = (e) => {
    const newContent = e.target.value;
    setContent(newContent);
    if (file && onContentChange) {
      onContentChange(file.id, newContent);
    }
    updateCursorPosition(e.target);
  };

  const updateCursorPosition = (textarea) => {
    const text = textarea.value;
    const cursorPos = textarea.selectionStart;
    const textBeforeCursor = text.substring(0, cursorPos);
    const lines = textBeforeCursor.split("\n");
    const line = lines.length;
    const column = lines[lines.length - 1].length + 1;
    setCursorPosition({ line, column });
  };

  const handleKeyDown = (e) => {
    const textarea = e.target;

    // Auto-indentation on Enter
    if (e.key === "Enter") {
      e.preventDefault();
      const start = textarea.selectionStart;
      const lines = content.substring(0, start).split("\n");
      const currentLine = lines[lines.length - 1];
      const indent = currentLine.match(/^\s*/)[0];

      // Add extra indent for opening braces
      const extraIndent =
        currentLine.trim().endsWith("{") ||
        currentLine.trim().endsWith("[") ||
        currentLine.trim().endsWith("(")
          ? "  "
          : "";
      const newContent =
        content.substring(0, start) +
        "\n" +
        indent +
        extraIndent +
        content.substring(start);

      setContent(newContent);
      if (file && onContentChange) {
        onContentChange(file.id, newContent);
      }

      setTimeout(() => {
        textarea.selectionStart = textarea.selectionEnd =
          start + 1 + indent.length + extraIndent.length;
        updateCursorPosition(textarea);
      });
    }

    // Tab support
    else if (e.key === "Tab") {
      e.preventDefault();
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const newContent =
        content.substring(0, start) + "  " + content.substring(end);
      setContent(newContent);
      if (file && onContentChange) {
        onContentChange(file.id, newContent);
      }

      setTimeout(() => {
        textarea.selectionStart = textarea.selectionEnd = start + 2;
        updateCursorPosition(textarea);
      }, 0);
    }

    // Search shortcut
    else if ((e.ctrlKey || e.metaKey) && e.key === "f") {
      e.preventDefault();
      setShowSearch(!showSearch);
    }

    // Auto-completion for JavaScript
    else if (file?.language === "javascript") {
      if (
        e.key === "(" ||
        e.key === "{" ||
        e.key === "[" ||
        e.key === '"' ||
        e.key === "'"
      ) {
        e.preventDefault();
        insertAutoComplete(textarea, e.key);
      }
    }
  };

  const insertAutoComplete = (textarea, char) => {
    const pairs = {
      "(": "()",
      "{": "{}",
      "[": "[]",
      '"': '""',
      "'": "''",
    };

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const pair = pairs[char];
    const newContent =
      content.substring(0, start) + pair + content.substring(end);

    setContent(newContent);
    if (file && onContentChange) {
      onContentChange(file.id, newContent);
    }

    setTimeout(() => {
      textarea.selectionStart = textarea.selectionEnd = start + 1;
      updateCursorPosition(textarea);
    });
  };

  const performSearch = () => {
    if (!searchQuery || !content) return;

    const index = content.toLowerCase().indexOf(searchQuery.toLowerCase());
    if (index !== -1 && textareaRef.current) {
      textareaRef.current.focus();
      textareaRef.current.setSelectionRange(index, index + searchQuery.length);
    }
  };

  const getLanguageLabel = (language) => {
    const labels = {
      javascript: "JavaScript",
      typescript: "TypeScript",
      python: "Python",
      css: "CSS",
      html: "HTML",
      json: "JSON",
      markdown: "Markdown",
    };
    return labels[language] || "Text";
  };

  const getLanguageIcon = (language) => {
    const icons = {
      javascript: "🟨",
      typescript: "🔷",
      python: "🐍",
      css: "🎨",
      html: "🌐",
      json: "📄",
      markdown: "📝",
    };
    return icons[language] || "📄";
  };

  const getLineNumbers = () => {
    const lines = content.split("\n");
    return lines.map((_, index) => index + 1);
  };

  if (!file) {
    return (
      <div className="h-full flex items-center justify-center bg-[#1e1e1e] text-gray-500">
        <div className="text-center">
          <div className="text-6xl mb-4">📝</div>
          <div className="text-lg mb-2">Select a file to start coding</div>
          <div className="text-sm">
            Choose a file from the explorer or create a new one
          </div>
          <div className="text-xs mt-4 text-gray-600">
            Features: Auto-completion • Syntax highlighting • Search (Ctrl+F) •
            Auto-indent
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-[#1e1e1e]">
      {/* File tab */}
      <div className="h-10 bg-[#2d2d30] border-b border-[#3e3e42] flex items-center justify-between px-4">
        <div className="flex items-center space-x-2">
          <span className="text-sm">{getLanguageIcon(file.language)}</span>
          <span className="text-sm text-gray-300">{file.name}</span>
          <span className="text-xs text-gray-500">
            • {getLanguageLabel(file.language)}
          </span>
        </div>
        <button
          onClick={() => setShowSearch(!showSearch)}
          className="p-1 text-gray-400 hover:text-white hover:bg-[#3e3e42] rounded transition-colors"
        >
          <Search size={14} />
        </button>
      </div>

      {/* Search bar */}
      {showSearch && (
        <div className="bg-[#2d2d30] border-b border-[#3e3e42] px-4 py-2">
          <div className="flex items-center space-x-2">
            <input
              ref={searchInputRef}
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && performSearch()}
              placeholder="Search in file..."
              className="flex-1 bg-[#1e1e1e] text-white px-3 py-1 rounded text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
            <button
              onClick={performSearch}
              className="px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700 transition-colors"
            >
              Find
            </button>
            <button
              onClick={() => setShowSearch(false)}
              className="p-1 text-gray-400 hover:text-white transition-colors"
            >
              <X size={14} />
            </button>
          </div>
        </div>
      )}

      {/* Editor area */}
      <div className="flex-1 flex">
        {/* Line numbers */}
        <div className="min-w-[60px] bg-[#1e1e1e] border-r border-[#3e3e42] py-4 text-right pr-3 text-xs text-gray-500 font-mono select-none">
          {getLineNumbers().map((lineNum) => (
            <div key={lineNum} className="leading-6 h-6">
              {lineNum}
            </div>
          ))}
        </div>

        {/* Code textarea */}
        <div className="flex-1 relative">
          <textarea
            ref={textareaRef}
            value={content}
            onChange={handleContentChange}
            onKeyDown={handleKeyDown}
            onSelect={(e) => updateCursorPosition(e.target)}
            onClick={(e) => updateCursorPosition(e.target)}
            className="w-full h-full p-4 bg-[#1e1e1e] text-gray-300 font-mono text-sm leading-6 resize-none focus:outline-none"
            style={{
              tabSize: 2,
              fontFamily: "'Monaco', 'Menlo', 'Ubuntu Mono', monospace",
            }}
            placeholder={`Start typing your ${getLanguageLabel(file.language)} code...`}
            spellCheck={false}
            autoComplete="off"
            autoCorrect="off"
            autoCapitalize="off"
          />
        </div>
      </div>

      {/* Editor status bar */}
      <div className="h-6 bg-[#007acc] flex items-center justify-between px-4 text-xs text-white">
        <div className="flex items-center space-x-4">
          <span>
            Ln {cursorPosition.line}, Col {cursorPosition.column}
          </span>
          <span>{getLanguageLabel(file.language)}</span>
          <span>Lines: {getLineNumbers().length}</span>
        </div>
        <div className="flex items-center space-x-4">
          <span>UTF-8</span>
          <span>LF</span>
          <span>Auto-complete: ON</span>
        </div>
      </div>
    </div>
  );
}
