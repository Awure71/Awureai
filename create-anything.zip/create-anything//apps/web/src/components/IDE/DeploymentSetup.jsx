import { useState, useEffect } from "react";
import {
  Key,
  ExternalLink,
  Copy,
  Check,
  AlertCircle,
  Info,
  CheckCircle,
} from "lucide-react";

export function DeploymentSetup({ provider, onComplete, onCancel }) {
  const [token, setToken] = useState("");
  const [isValidating, setIsValidating] = useState(false);
  const [copied, setCopied] = useState(false);

  const providerInfo = {
    vercel: {
      name: "Vercel",
      tokenUrl: "https://vercel.com/account/tokens",
      tokenName: "VERCEL_TOKEN",
      description: "Create a new token with deployment permissions",
      steps: [
        "Go to Vercel Dashboard → Settings → Tokens",
        "Click 'Create Token'",
        "Give it a name (e.g., 'AwureAI Deployments')",
        "Select 'Full Access' scope",
        "Copy the token and paste it below",
      ],
    },
    netlify: {
      name: "Netlify",
      tokenUrl:
        "https://app.netlify.com/user/applications#personal-access-tokens",
      tokenName: "NETLIFY_TOKEN",
      description: "Create a personal access token",
      steps: [
        "Go to Netlify → User Settings → Applications",
        "Scroll to 'Personal access tokens'",
        "Click 'New access token'",
        "Give it a description (e.g., 'AwureAI Deployments')",
        "Copy the token and paste it below",
      ],
    },
    "awureai-hosting": {
      name: "AwureAI Hosting (Demo)",
      tokenUrl: "#",
      tokenName: "DEMO_TOKEN",
      description: "Demo deployment - no setup required",
      steps: [
        "This is a demo provider for testing purposes",
        "No setup or authentication is required",
        "Click 'Setup Demo Deployment' to continue",
      ],
    },
  };

  const info = providerInfo[provider];

  // Handle invalid or missing provider
  if (!info) {
    return (
      <div className="max-w-2xl mx-auto p-6">
        <div className="text-center">
          <div className="flex items-center justify-center mb-4">
            <div className="p-3 bg-red-100 rounded-full">
              <AlertCircle className="text-red-600" size={24} />
            </div>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Invalid Provider
          </h2>
          <p className="text-gray-600 mb-6">
            The deployment provider "{provider}" is not supported.
          </p>
          <button
            onClick={onCancel}
            className="px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-md transition-colors"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  const copyEnvVar = () => {
    navigator.clipboard.writeText(`${info.tokenName}=${token}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const validateAndComplete = async () => {
    // For demo provider, skip token validation
    if (provider === "awureai-hosting") {
      setIsValidating(true);
      setTimeout(() => {
        setIsValidating(false);
        onComplete("DEMO_TOKEN", "demo-deployment-ready");
      }, 1000);
      return;
    }

    if (!token.trim()) return;

    setIsValidating(true);

    // Simulate validation (in real app, you'd test the token)
    setTimeout(() => {
      setIsValidating(false);
      onComplete(info.tokenName, token);
    }, 1500);
  };

  // Special handling for demo provider
  if (provider === "awureai-hosting") {
    return (
      <div className="max-w-2xl mx-auto p-6">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="p-3 bg-green-100 rounded-full">
              <CheckCircle className="text-green-600" size={24} />
            </div>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Demo Deployment Ready!
          </h2>
          <p className="text-gray-600">
            No setup required for the demo deployment. Click continue to
            proceed.
          </p>
        </div>

        <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
          <div className="flex items-start space-x-3">
            <Info className="text-green-600 flex-shrink-0 mt-0.5" size={18} />
            <div>
              <h3 className="text-green-900 font-medium mb-2">
                About Demo Deployment:
              </h3>
              <ul className="list-disc list-inside text-sm text-green-800 space-y-1">
                <li>Perfect for testing and prototyping</li>
                <li>No authentication or tokens required</li>
                <li>Simulated deployment process</li>
                <li>Creates a live preview URL</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="flex space-x-3">
          <button
            onClick={validateAndComplete}
            disabled={isValidating}
            className={`flex-1 py-2 px-4 rounded-md font-medium transition-colors ${
              !isValidating
                ? "bg-green-600 hover:bg-green-700 text-white"
                : "bg-gray-300 text-gray-500 cursor-not-allowed"
            }`}
          >
            {isValidating
              ? "Starting Demo..."
              : "Continue with Demo Deployment"}
          </button>
          <button
            onClick={onCancel}
            className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
          >
            Cancel
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto p-6">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center mb-4">
          <div className="p-3 bg-blue-100 rounded-full">
            <Key className="text-blue-600" size={24} />
          </div>
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">
          Setup {info.name} Deployment
        </h2>
        <p className="text-gray-600">{info.description}</p>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
        <div className="flex items-start space-x-3">
          <Info className="text-blue-600 flex-shrink-0 mt-0.5" size={18} />
          <div>
            <h3 className="text-blue-900 font-medium mb-2">
              How to get your {info.name} token:
            </h3>
            <ol className="list-decimal list-inside text-sm text-blue-800 space-y-1">
              {info.steps.map((step, index) => (
                <li key={index}>{step}</li>
              ))}
            </ol>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <label className="block text-sm font-medium text-gray-700">
            {info.name} Token
          </label>
          <a
            href={info.tokenUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center space-x-1 text-sm text-blue-600 hover:text-blue-700"
          >
            <span>Get Token</span>
            <ExternalLink size={14} />
          </a>
        </div>

        <div className="relative">
          <input
            type="password"
            value={token}
            onChange={(e) => setToken(e.target.value)}
            placeholder={`Paste your ${info.name} token here...`}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          {token && (
            <button
              onClick={copyEnvVar}
              className="absolute right-2 top-1/2 transform -translate-y-1/2 p-1 text-gray-400 hover:text-gray-600"
              title="Copy as environment variable"
            >
              {copied ? (
                <Check size={16} className="text-green-600" />
              ) : (
                <Copy size={16} />
              )}
            </button>
          )}
        </div>

        {token && (
          <div className="bg-gray-50 p-3 rounded-md">
            <div className="flex items-center space-x-2 text-sm text-gray-600 mb-2">
              <AlertCircle size={16} />
              <span>Environment Variable:</span>
            </div>
            <code className="text-sm bg-gray-100 px-2 py-1 rounded">
              {info.tokenName}={token.slice(0, 8)}...{token.slice(-4)}
            </code>
          </div>
        )}
      </div>

      <div className="flex space-x-3 mt-8">
        <button
          onClick={validateAndComplete}
          disabled={!token.trim() || isValidating}
          className={`flex-1 py-2 px-4 rounded-md font-medium transition-colors ${
            token.trim() && !isValidating
              ? "bg-blue-600 hover:bg-blue-700 text-white"
              : "bg-gray-300 text-gray-500 cursor-not-allowed"
          }`}
        >
          {isValidating ? "Validating..." : `Setup ${info.name} Deployment`}
        </button>
        <button
          onClick={onCancel}
          className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
        >
          Cancel
        </button>
      </div>

      <div className="mt-6 text-xs text-gray-500 text-center">
        Your token will be stored securely as an environment variable and used
        only for deployments.
      </div>
    </div>
  );
}
