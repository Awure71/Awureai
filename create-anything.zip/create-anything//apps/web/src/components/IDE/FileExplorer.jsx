import { useState } from "react";
import { File, Folder, FolderOpen, Plus, Trash2, FileText } from "lucide-react";

export function FileExplorer({
  files,
  activeFile,
  onFileSelect,
  onCreateFile,
  onDeleteFile,
}) {
  const [newFileName, setNewFileName] = useState("");
  const [isCreating, setIsCreating] = useState(false);

  const handleCreateFile = () => {
    if (newFileName.trim()) {
      onCreateFile(newFileName.trim());
      setNewFileName("");
      setIsCreating(false);
    }
  };

  const getFileIcon = (filename) => {
    const ext = filename.split(".").pop().toLowerCase();
    const iconMap = {
      js: "🟨",
      jsx: "🔵",
      ts: "🔷",
      tsx: "🔷",
      py: "🐍",
      css: "🎨",
      html: "🌐",
      json: "📋",
      md: "📝",
    };
    return iconMap[ext] || "📄";
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-3 border-b border-[#3e3e42] flex items-center justify-between">
        <h3 className="text-sm font-medium text-gray-300">FILES</h3>
        <button
          onClick={() => setIsCreating(true)}
          className="p-1 text-gray-400 hover:text-white hover:bg-[#3e3e42] rounded transition-colors"
        >
          <Plus size={16} />
        </button>
      </div>

      {/* File list */}
      <div className="flex-1 overflow-y-auto">
        {/* New file input */}
        {isCreating && (
          <div className="p-2 border-b border-[#3e3e42]">
            <input
              type="text"
              value={newFileName}
              onChange={(e) => setNewFileName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleCreateFile();
                if (e.key === "Escape") {
                  setIsCreating(false);
                  setNewFileName("");
                }
              }}
              onBlur={handleCreateFile}
              placeholder="filename.js"
              className="w-full px-2 py-1 bg-[#3c3c3c] text-white text-sm rounded border border-[#5a5a5a] focus:outline-none focus:border-blue-500"
              autoFocus
            />
          </div>
        )}

        {/* File items */}
        {files.map((file) => (
          <div
            key={file.id}
            className={`group flex items-center justify-between px-3 py-2 cursor-pointer hover:bg-[#2a2d2e] ${
              activeFile?.id === file.id
                ? "bg-[#37373d] border-l-2 border-blue-500"
                : ""
            }`}
            onClick={() => onFileSelect(file)}
          >
            <div className="flex items-center space-x-2 flex-1 min-w-0">
              <span className="text-sm">{getFileIcon(file.name)}</span>
              <span className="text-sm text-gray-300 truncate">
                {file.name}
              </span>
            </div>

            <button
              onClick={(e) => {
                e.stopPropagation();
                onDeleteFile(file.id);
              }}
              className="opacity-0 group-hover:opacity-100 p-1 text-gray-400 hover:text-red-400 transition-all"
            >
              <Trash2 size={14} />
            </button>
          </div>
        ))}

        {files.length === 0 && !isCreating && (
          <div className="p-4 text-center text-gray-500 text-sm">
            No files yet. Click the + button to create one.
          </div>
        )}
      </div>

      {/* Footer info */}
      <div className="p-3 border-t border-[#3e3e42] text-xs text-gray-500">
        {files.length} file{files.length !== 1 ? "s" : ""}
      </div>
    </div>
  );
}
