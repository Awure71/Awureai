import {
  ExternalLink,
  Key,
  Rocket,
  CheckCircle,
  AlertTriangle,
} from "lucide-react";

export function DeploymentGuide({ onClose }) {
  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Header */}
      <div className="text-center mb-8">
        <div className="flex items-center justify-center mb-4">
          <div className="p-3 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full">
            <Rocket className="text-white" size={24} />
          </div>
        </div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Real Deployment Guide
        </h1>
        <p className="text-gray-600 text-lg">
          Deploy your AwureAI projects to Vercel or Netlify
        </p>
      </div>

      {/* Quick Start */}
      <div className="bg-green-50 border border-green-200 rounded-lg p-6 mb-8">
        <div className="flex items-start space-x-3">
          <CheckCircle
            className="text-green-600 flex-shrink-0 mt-0.5"
            size={20}
          />
          <div>
            <h2 className="text-green-900 font-semibold mb-2">
              Quick Start (Recommended)
            </h2>
            <p className="text-green-800 mb-3">
              For testing purposes, use the "AwureAI Hosting (Demo)" option
              which works without any setup.
            </p>
            <div className="flex items-center space-x-2">
              <span className="inline-flex items-center px-2 py-1 bg-green-100 text-green-800 text-xs font-medium rounded">
                ⚡ Demo Mode
              </span>
              <span className="text-sm text-green-700">
                No tokens required • Instant deployment
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Providers */}
      <div className="grid md:grid-cols-2 gap-8 mb-8">
        {/* Vercel */}
        <div className="border border-gray-200 rounded-lg p-6">
          <div className="flex items-center space-x-3 mb-4">
            <span className="text-2xl">▲</span>
            <h3 className="text-xl font-semibold text-gray-900">Vercel</h3>
          </div>

          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-gray-900 mb-2">What you get:</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Automatic HTTPS</li>
                <li>• Global CDN</li>
                <li>• Custom domains</li>
                <li>• Instant deployments</li>
              </ul>
            </div>

            <div>
              <h4 className="font-medium text-gray-900 mb-2">Setup steps:</h4>
              <ol className="text-sm text-gray-600 space-y-1">
                <li>1. Sign up at vercel.com</li>
                <li>2. Go to Settings → Tokens</li>
                <li>3. Create a new token</li>
                <li>4. Use it in AwureAI deployment</li>
              </ol>
            </div>

            <a
              href="https://vercel.com/account/tokens"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-1 text-blue-600 hover:text-blue-700 text-sm"
            >
              <Key size={14} />
              <span>Get Vercel Token</span>
              <ExternalLink size={14} />
            </a>
          </div>
        </div>

        {/* Netlify */}
        <div className="border border-gray-200 rounded-lg p-6">
          <div className="flex items-center space-x-3 mb-4">
            <span className="text-2xl">🚀</span>
            <h3 className="text-xl font-semibold text-gray-900">Netlify</h3>
          </div>

          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-gray-900 mb-2">What you get:</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Free hosting</li>
                <li>• Form handling</li>
                <li>• Edge functions</li>
                <li>• Branch previews</li>
              </ul>
            </div>

            <div>
              <h4 className="font-medium text-gray-900 mb-2">Setup steps:</h4>
              <ol className="text-sm text-gray-600 space-y-1">
                <li>1. Sign up at netlify.com</li>
                <li>2. Go to User Settings → Applications</li>
                <li>3. Create personal access token</li>
                <li>4. Use it in AwureAI deployment</li>
              </ol>
            </div>

            <a
              href="https://app.netlify.com/user/applications#personal-access-tokens"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-1 text-blue-600 hover:text-blue-700 text-sm"
            >
              <Key size={14} />
              <span>Get Netlify Token</span>
              <ExternalLink size={14} />
            </a>
          </div>
        </div>
      </div>

      {/* How it works */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-8">
        <h3 className="text-blue-900 font-semibold mb-3">
          How Real Deployment Works
        </h3>
        <div className="grid md:grid-cols-3 gap-4">
          <div className="text-center">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
              <span className="text-blue-600 font-bold">1</span>
            </div>
            <p className="text-sm text-blue-800">
              Your project files are packaged and prepared for deployment
            </p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
              <span className="text-blue-600 font-bold">2</span>
            </div>
            <p className="text-sm text-blue-800">
              Files are uploaded to your chosen provider using their API
            </p>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
              <span className="text-blue-600 font-bold">3</span>
            </div>
            <p className="text-sm text-blue-800">
              Your site goes live instantly with a public URL
            </p>
          </div>
        </div>
      </div>

      {/* Security Note */}
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-8">
        <div className="flex items-start space-x-3">
          <AlertTriangle
            className="text-yellow-600 flex-shrink-0 mt-0.5"
            size={18}
          />
          <div>
            <h4 className="text-yellow-900 font-medium mb-1">Security Note</h4>
            <p className="text-sm text-yellow-800">
              Your API tokens are stored securely as environment variables and
              are only used for deployment. Never share your tokens publicly or
              in client-side code.
            </p>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex space-x-4">
        <button
          onClick={onClose}
          className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-6 rounded-lg transition-colors flex items-center justify-center space-x-2"
        >
          <Rocket size={18} />
          <span>Start Deploying</span>
        </button>
      </div>
    </div>
  );
}
