import { Wifi, GitBranch, AlertCircle, CheckCircle, Save } from "lucide-react";

export function StatusBar({ activeFile, isSaving }) {
  const getLanguageLabel = (language) => {
    const labels = {
      javascript: "JavaScript",
      typescript: "TypeScript",
      python: "Python",
      css: "CSS",
      html: "HTML",
      json: "JSON",
      markdown: "Markdown",
    };
    return labels[language] || "Text";
  };

  return (
    <div className="h-6 bg-[#007acc] flex items-center justify-between px-4 text-xs text-white">
      {/* Left side - File info */}
      <div className="flex items-center space-x-4">
        {activeFile && (
          <>
            <span>{activeFile.name}</span>
            <span>•</span>
            <span>{getLanguageLabel(activeFile.language)}</span>
          </>
        )}
        {isSaving && (
          <div className="flex items-center space-x-1">
            <Save size={10} className="animate-pulse" />
            <span>Auto-saving...</span>
          </div>
        )}
      </div>

      {/* Right side - Status indicators */}
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-1">
          <GitBranch size={12} />
          <span>main</span>
        </div>

        <div className="flex items-center space-x-1">
          <CheckCircle size={12} />
          <span>No errors</span>
        </div>

        <div className="flex items-center space-x-1">
          <Wifi size={12} />
          <span>Connected</span>
        </div>

        <span>UTF-8</span>
        <span>LF</span>
        <span>Spaces: 2</span>
      </div>
    </div>
  );
}
